import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, Globe } from 'lucide-react';
import { useTranslation } from '@/hooks/useTranslation.js';

function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { t, language, setLanguage } = useTranslation();

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const toggleLanguage = () => {
    const newLang = language === 'fr' ? 'en' : 'fr';
    setLanguage(newLang);
    let pathWithoutLang = location.pathname.replace(/^\/(fr|en)/, '');
    const enToFr = {
      '/events/international-youth-day': '/evenements/journee-internationale-de-la-jeunesse',
      '/events': '/evenements',
    };
    const frToEn = {
      '/evenements/journee-internationale-de-la-jeunesse': '/events/international-youth-day',
      '/evenements': '/events',
    };
    if (newLang === 'fr' && enToFr[pathWithoutLang]) pathWithoutLang = enToFr[pathWithoutLang];
    if (newLang === 'en' && frToEn[pathWithoutLang]) pathWithoutLang = frToEn[pathWithoutLang];
    navigate(`/${newLang}${pathWithoutLang === '' ? '/' : pathWithoutLang}`);
  };

  const eventsPath = language === 'fr' ? `/${language}/evenements` : `/${language}/events`;

  const navItems = [
    { name: t('nav.home') || 'Accueil', path: `/${language}` },
    { name: t('nav.about') || 'À Propos', path: `/${language}/a-propos` },
    { name: t('nav.programs') || 'Programmes', path: `/${language}/programmes` },
    { name: language === 'fr' ? 'Enfants' : 'Children', path: `/${language}/children` },
    { name: t('nav.events') || (language === 'fr' ? 'Événements' : 'Events'), path: eventsPath },
    { name: t('nav.budget') || 'Budget', path: `/${language}/budget` },
    { name: t('nav.contact') || 'Contact', path: `/${language}/nous-contacter` },
  ];

  const isActive = (path) => {
    if (path === `/${language}` && location.pathname === `/${language}`) return true;
    if (path !== `/${language}` && location.pathname.startsWith(path)) return true;
    return false;
  };

  return (
    <header
      className={`sticky top-0 z-50 bg-white transition-shadow duration-300 ${scrolled ? 'shadow-md' : 'border-b border-border'}`}
    >
      <div className="container-wp">
        <div className="flex items-center justify-between h-16 md:h-20">

          {/* Logo */}
          <Link to={`/${language}`} className="flex items-center gap-3 group flex-shrink-0">
            <img
              src="https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/ef2e8647070154ddb8aa4e2f108de783.jpg"
              alt="Iradukunda Natwe ASBL"
              className="h-9 w-9 md:h-11 md:w-11 rounded object-cover"
            />
            <span
              className="text-lg md:text-xl font-extrabold uppercase tracking-tight leading-none text-foreground group-hover:text-primary transition-colors duration-200"
              style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
            >
              Iradukunda Natwe
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-0 ml-10 flex-1">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`px-4 py-2 text-sm font-medium transition-colors duration-200 border-b-2 -mb-px relative top-px ${
                  isActive(item.path)
                    ? 'text-primary border-accent'
                    : 'text-foreground hover:text-primary border-transparent hover:border-primary/30'
                }`}
              >
                {item.name}
              </Link>
            ))}
          </nav>

          {/* Desktop Actions */}
          <div className="hidden lg:flex items-center gap-3 ml-4 flex-shrink-0">
            <Link
              to={`/${language}/donate`}
              className="inline-flex items-center px-5 py-2.5 text-sm font-bold uppercase tracking-wider rounded-sm transition-all duration-200 hover:opacity-90"
              style={{ backgroundColor: 'hsl(43,96%,50%)', color: '#2B3441', fontFamily: "'Barlow Condensed', sans-serif" }}
            >
              {t('nav.donate') || 'Faire un don'}
            </Link>
            <button
              onClick={toggleLanguage}
              className="flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-primary transition-colors px-3 py-2 rounded hover:bg-muted"
            >
              <Globe className="w-4 h-4" />
              <span>{language === 'fr' ? 'EN' : 'FR'}</span>
            </button>
          </div>

          {/* Mobile Toggle */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={toggleLanguage}
              className="p-2 text-muted-foreground hover:text-primary transition-colors rounded"
            >
              <Globe className="w-4 h-4" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-foreground hover:text-primary transition-colors rounded"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-t border-border shadow-lg">
          <div className="container-wp py-3 flex flex-col">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`py-3 px-2 text-sm font-medium border-b border-border/50 transition-colors ${
                  isActive(item.path) ? 'text-primary' : 'text-foreground hover:text-primary'
                }`}
              >
                {item.name}
              </Link>
            ))}
            <Link
              to={`/${language}/donate`}
              className="mt-2 inline-flex items-center justify-center px-5 py-3 text-sm font-bold uppercase tracking-wider rounded-sm"
              style={{ backgroundColor: 'hsl(43,96%,50%)', color: '#2B3441', fontFamily: "'Barlow Condensed', sans-serif" }}
            >
              {t('nav.donate') || 'Faire un don'}
            </Link>

          </div>
        </div>
      )}
    </header>
  );
}

export default Header;
