import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from '../hooks/useTranslation.js';
function Footer() {
  const {
    t,
    language
  } = useTranslation();
  const currentYear = new Date().getFullYear();
  return <footer style={{
    backgroundColor: '#2B3441'
  }} className="text-white">
      <div className="container-wp py-14 md:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-16 mb-14">

          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-5">
              <img src="https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/ef2e8647070154ddb8aa4e2f108de783.jpg" alt="Iradukunda Natwe ASBL" className="h-10 w-10 rounded object-cover" />
              <span className="text-xl font-extrabold uppercase leading-tight text-white" style={{
              fontFamily: "'Barlow Condensed', sans-serif"
            }}>
                Iradukunda Natwe
              </span>
            </div>
            <p className="text-white/60 text-sm leading-relaxed mb-0" style={{
            maxWidth: '28ch'
          }}>
              {t('footer.tagline') || 'Autonomiser et Protéger — Burundi'}
            </p>
            <p className="text-white/50 text-xs leading-relaxed mt-4 mb-0">
              Iradukunda Natwe Asbl<br />
              Bujumbura Burundi<br />
              MOIPS: 530/109741312026
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="text-xs font-bold tracking-widest uppercase text-white/40 mb-5" style={{
            fontFamily: "'Barlow Condensed', sans-serif"
          }}>
              {t('footer.nav') || 'Navigation'}
            </h4>
            <ul className="space-y-3">
              {[{
              label: t('nav.home') || 'Accueil',
              path: `/${language}`
            }, {
              label: t('nav.about') || 'À Propos',
              path: `/${language}/a-propos`
            }, {
              label: t('nav.programs') || 'Programmes',
              path: `/${language}/programmes`
            }, {
              label: language === 'fr' ? 'Enfants soutenus' : 'Children We Support',
              path: `/${language}/children`
            }, {
              label: t('nav.events') || (language === 'fr' ? 'Événements' : 'Events'),
              path: language === 'fr' ? `/${language}/evenements` : `/${language}/events`
            }, {
              label: t('nav.budget') || 'Budget',
              path: `/${language}/budget`
            }, {
              label: t('nav.contact') || 'Contact',
              path: `/${language}/nous-contacter`
            }, {
              label: t('nav.donate') || (language === 'fr' ? 'Faire un don' : 'Donate'),
              path: `/${language}/donate`
            }].map(item => <li key={item.path}>
                  <Link to={item.path} className="text-sm text-white/70 hover:text-white transition-colors duration-200">
                    {item.label}
                  </Link>
                </li>)}
            </ul>
          </div>

          {/* Focus Areas */}
          <div>
            <h4 className="text-xs font-bold tracking-widest uppercase text-white/40 mb-5" style={{
            fontFamily: "'Barlow Condensed', sans-serif"
          }}>
              {t('footer.axes') || 'Axes d\'Intervention'}
            </h4>
            <ul className="space-y-3">
              <li className="text-sm text-white/70">{language === 'fr' ? 'Autonomisation des femmes' : 'Women Empowerment'}</li>
              <li className="text-sm text-white/70">{language === 'fr' ? 'Protection & éducation' : 'Child Protection & Education'}</li>
              <li className="text-sm text-white/70">{language === 'fr' ? 'Durabilité environnementale' : 'Environmental Sustainability'}</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-xs font-bold tracking-widest uppercase text-white/40 mb-5" style={{
            fontFamily: "'Barlow Condensed', sans-serif"
          }}>
              {t('footer.contact') || 'Contact'}
            </h4>
            <address className="not-italic text-sm text-white/70 space-y-3">
              <p className="mb-0">
                Bujumbura, Commune Mugere<br />
                Zone Musaga, Quartier Kinanira I
              </p>
              <p className="mb-0">
                <a href="mailto:contact@iradukunda.org" className="hover:text-white transition-colors">
                  contact@iradukunda.org
                </a>
              </p>
              <p className="mb-0"><a href="https://www.iradukunda.org" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">www.iradukunda.org</a>&nbsp;| {language === 'fr' ? "Site officiel de l'association IRADUKUNDA NATWE." : 'Official Website for the Association IRADUKUNDA NATWE.'}</p>
            </address>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-white/40">
            &copy; {currentYear} Iradukunda Natwe ASBL. {t('footer.rights') || 'Tous droits réservés.'}
          </p>
          <div className="flex gap-6">
            <Link to={`/${language}/privacy`} className="text-sm text-white/40 hover:text-white/80 transition-colors">
              {t('nav.privacy') || (language === 'fr' ? 'Confidentialité' : 'Privacy Policy')}
            </Link>
            <Link to={`/${language}/donate`} className="text-sm text-white/40 hover:text-white/80 transition-colors">
              {t('nav.donate') || (language === 'fr' ? 'Faire un don' : 'Donate')}
            </Link>
          </div>
        </div>
      </div>
    </footer>;
}
export default Footer;