import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Shield } from 'lucide-react';
import { useTranslation } from '../hooks/useTranslation.js';

function PrivacyPolicyPage() {
  const { t, language } = useTranslation();

  const sections = [
    { title: t('privacy.introTitle'), body: t('privacy.intro') },
    { title: t('privacy.collectTitle'), body: t('privacy.collect') },
    { title: t('privacy.useTitle'), body: t('privacy.use') },
    { title: t('privacy.cookiesTitle'), body: t('privacy.cookies') },
    { title: t('privacy.thirdTitle'), body: t('privacy.third') },
    { title: t('privacy.rightsTitle'), body: t('privacy.rights') },
    { title: t('privacy.securityTitle'), body: t('privacy.security') },
    { title: t('privacy.contactTitle'), body: t('privacy.contact') },
  ];

  return (
    <>
      <Helmet>
        <title>{t('privacy.title')} — Iradukunda Natwe ASBL</title>
        <meta name="description" content={t('privacy.desc')} />
      </Helmet>

      {/* Page Header */}
      <section className="page-header">
        <div className="container-wp max-w-5xl">
          <nav className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-8">
            <Link to={`/${language}`} className="hover:text-primary transition-colors">{t('nav.home') || 'Accueil'}</Link>
            <span>/</span>
            <span>{t('privacy.subtitle') || 'Confidentialité'}</span>
          </nav>
          <p className="section-label mb-3">{t('privacy.subtitle') || 'Confidentialité'}</p>
          <h1
            className="m-0 mb-5 leading-tight"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: 'clamp(2.2rem, 5vw, 4.5rem)',
              fontWeight: 800,
              textTransform: 'uppercase',
              letterSpacing: '-0.01em',
            }}
          >
            {t('privacy.title') || 'Politique de Confidentialité'}
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mb-0">{t('privacy.desc')}</p>
        </div>
      </section>

      {/* Body */}
      <section className="py-20 md:py-28 bg-white border-b border-border">
        <div className="container-wp max-w-3xl">
          <div className="flex items-center gap-3 mb-10">
            <div
              className="flex-shrink-0 w-10 h-10 flex items-center justify-center rounded-sm"
              style={{ backgroundColor: 'hsl(43,96%,50%)' }}
            >
              <Shield className="w-5 h-5" style={{ color: '#2B3441' }} />
            </div>
            <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground m-0" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
              {t('privacy.updated') || 'Dernière mise à jour'}
            </p>
          </div>

          <div className="divide-y divide-border">
            {sections.map((s, i) => (
              <div key={i} className="py-8 first:pt-0">
                <h2
                  className="text-xl md:text-2xl font-bold mb-4"
                  style={{ fontFamily: "'Merriweather', serif" }}
                >
                  {s.title}
                </h2>
                <p className="text-muted-foreground leading-relaxed mb-0 max-w-none">{s.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default PrivacyPolicyPage;
