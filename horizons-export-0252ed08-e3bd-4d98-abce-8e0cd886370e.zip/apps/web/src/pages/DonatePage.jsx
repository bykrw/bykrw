import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowRight, Mail, HandHeart } from 'lucide-react';
import { useTranslation } from '../hooks/useTranslation.js';

function DonatePage() {
  const { t, language } = useTranslation();

  const items = t('donate.items') || [];

  return (
    <>
      <Helmet>
        <title>{t('donate.title')} — Iradukunda Natwe ASBL</title>
        <meta name="description" content={t('donate.desc')} />
      </Helmet>

      {/* Page Header */}
      <section className="page-header">
        <div className="container-wp max-w-5xl">
          <nav className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-8">
            <Link to={`/${language}`} className="hover:text-primary transition-colors">{t('nav.home') || 'Accueil'}</Link>
            <span>/</span>
            <span>{t('donate.subtitle') || 'Faire un don'}</span>
          </nav>
          <p className="section-label mb-3">{t('donate.subtitle') || 'Faire un don'}</p>
          <h1
            className="m-0 mb-5 leading-tight"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: 'clamp(2.2rem, 5vw, 4.5rem)',
              fontWeight: 800,
              textTransform: 'uppercase',
              letterSpacing: '-0.01em',
            }}
          >
            {t('donate.title') || 'Soutenez Notre Mission'}
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mb-0">{t('donate.desc')}</p>
        </div>
      </section>

      {/* Why give */}
      <section className="py-20 md:py-28 bg-white border-b border-border">
        <div className="container-wp max-w-5xl">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-0 border border-border">
            <div className="p-10 md:p-14 border-b md:border-b-0 md:border-r border-border">
              <p className="section-label mb-4">{language === 'fr' ? 'Notre engagement' : 'Our commitment'}</p>
              <h2
                className="text-2xl md:text-3xl font-bold mb-5"
                style={{ fontFamily: "'Merriweather', serif" }}
              >
                {t('donate.whyTitle') || 'Pourquoi donner ?'}
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-0">{t('donate.why')}</p>
            </div>
            <div className="p-10 md:p-14 flex flex-col justify-center">
              <p className="section-label mb-4">{t('donate.impactTitle') || 'Votre impact'}</p>
              <ul className="space-y-5 m-0 p-0 list-none">
                {items.map((item, i) => (
                  <li key={i} className="flex items-start gap-4">
                    <span
                      className="flex-shrink-0 text-2xl font-extrabold leading-none"
                      style={{ fontFamily: "'Barlow Condensed', sans-serif", color: 'hsl(213,60%,35%)' }}
                    >
                      {item.amount}
                    </span>
                    <span className="text-muted-foreground text-sm leading-relaxed pt-1">{item.impact}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* How to donate */}
      <section className="section-dark py-20 md:py-28">
        <div className="container-wp max-w-3xl text-center">
          <div
            className="inline-flex items-center justify-center w-12 h-12 rounded-sm mb-6"
            style={{ backgroundColor: 'hsl(43,96%,50%)' }}
          >
            <HandHeart className="w-6 h-6" style={{ color: '#2B3441' }} />
          </div>
          <h2
            className="display-title text-white m-0 mb-5"
          >
            {t('donate.howTitle') || 'Comment faire un don'}
          </h2>
          <p className="text-white/60 leading-relaxed mb-10 max-w-xl mx-auto">{t('donate.howDesc')}</p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="mailto:contact@iradukunda.org"
              className="inline-flex items-center gap-2 px-7 py-3.5 text-sm font-bold uppercase tracking-wider rounded-sm transition-all duration-200 hover:opacity-90 flex-shrink-0"
              style={{ backgroundColor: 'hsl(43,96%,50%)', color: '#2B3441', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem' }}
            >
              <Mail className="w-4 h-4" />
              {t('donate.emailBtn') || 'Écrire à contact@iradukunda.org'}
            </a>
            <Link
              to={`/${language}/nous-contacter`}
              className="inline-flex items-center gap-2 px-7 py-3.5 text-sm font-bold uppercase tracking-wider rounded-sm border border-white/30 text-white hover:bg-white/10 transition-colors duration-200 flex-shrink-0"
              style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem' }}
            >
              {t('donate.contactBtn') || 'Nous contacter'}
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Partner CTA */}
      <section className="py-16 bg-muted/30 border-b border-border">
        <div className="container-wp max-w-5xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h3
              className="text-xl font-bold text-foreground m-0 mb-2"
              style={{ fontFamily: "'Merriweather', serif" }}
            >
              {t('donate.partnerTitle') || 'Devenir partenaire'}
            </h3>
            <p className="text-muted-foreground text-sm m-0 max-w-xl">{t('donate.partnerDesc')}</p>
          </div>
          <Link
            to={`/${language}/nous-contacter`}
            className="inline-flex items-center gap-2 px-7 py-3.5 text-sm font-bold uppercase tracking-wider rounded-sm transition-all duration-200 hover:opacity-90 flex-shrink-0"
            style={{ backgroundColor: 'hsl(213,60%,35%)', color: 'white', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem' }}
          >
            {t('nav.partner') || 'Devenir partenaire'}
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>
    </>
  );
}

export default DonatePage;
