import React, { createContext, useState, useEffect } from 'react';
import pb from '@/lib/pocketbaseClient.js';

export const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(pb.authStore.model);
  const [isAuthenticated, setIsAuthenticated] = useState(pb.authStore.isValid);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Initial check
    setCurrentUser(pb.authStore.model);
    setIsAuthenticated(pb.authStore.isValid);
    setLoading(false);

    // Subscribe to auth state changes
    const unsubscribe = pb.authStore.onChange((token, model) => {
      setCurrentUser(model);
      setIsAuthenticated(!!model);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const login = async (email, password) => {
    try {
      const authData = await pb.collection('users').authWithPassword(email, password, { $autoCancel: false });
      return authData;
    } catch (error) {
      throw error;
    }
  };

  const signup = async (data) => {
    try {
      const record = await pb.collection('users').create(data, { $autoCancel: false });
      return record;
    } catch (error) {
      throw error;
    }
  };

  const logout = () => {
    pb.authStore.clear();
  };

  const resetPassword = async (email) => {
    try {
      await pb.collection('users').requestPasswordReset(email, { $autoCancel: false });
    } catch (error) {
      throw error;
    }
  };

  const value = {
    currentUser,
    isAuthenticated,
    loading,
    login,
    signup,
    logout,
    resetPassword
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}