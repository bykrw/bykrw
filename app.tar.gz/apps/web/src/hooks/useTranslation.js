import { useContext } from 'react';
import { LanguageContext } from '../context/LanguageContext.jsx';
import { translations } from '../lib/translations.js';

export function useTranslation() {
  const context = useContext(LanguageContext);
  
  if (!context) {
    throw new Error('useTranslation must be used within a LanguageProvider');
  }

  const { language, setLanguage } = context;

  const t = (key) => {
    const keys = key.split('.');
    let value = translations[language];
    
    for (const k of keys) {
      if (value && value[k]) {
        value = value[k];
      } else {
        return key; // Fallback to key if translation is missing
      }
    }
    
    return value;
  };

  return { t, language, setLanguage };
}