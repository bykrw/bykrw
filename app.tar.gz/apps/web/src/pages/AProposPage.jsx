import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { useTranslation } from '../hooks/useTranslation.js';

function AProposPage() {
  const { t, language } = useTranslation();

  const values = [
    { title: t('about.values.love.title'), description: t('about.values.love.desc') },
    { title: t('about.values.equity.title'), description: t('about.values.equity.desc') },
    { title: t('about.values.integrity.title'), description: t('about.values.integrity.desc') },
  ];

  return (
    <>
      <Helmet>
        <title>{t('about.title')} — Iradukunda Natwe ASBL</title>
        <meta name="description" content={t('about.desc')} />
      </Helmet>

      {/* Page Header */}
      <section className="page-header">
        <div className="container-wp max-w-5xl">
          <nav className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-8">
            <Link to={`/${language}`} className="hover:text-primary transition-colors">{t('nav.home') || 'Accueil'}</Link>
            <span>/</span>
            <span>{t('about.subtitle') || 'À Propos'}</span>
          </nav>
          <p className="section-label mb-3">{t('about.subtitle') || 'À Propos'}</p>
          <h1
            className="m-0 mb-5 leading-tight"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: 'clamp(2.2rem, 5vw, 4.5rem)',
              fontWeight: 800,
              textTransform: 'uppercase',
              letterSpacing: '-0.01em',
            }}
          >
            {t('about.title') || 'Notre Identité'}
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mb-0">
            {t('about.desc')}
          </p>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 md:py-28 border-b border-border bg-white">
        <div className="container-wp">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-0 border border-border">
            <div className="p-10 md:p-14 border-b md:border-b-0 md:border-r border-border">
              <p className="section-label mb-4">{language === 'fr' ? 'Mission' : 'Mission'}</p>
              <h2
                className="text-2xl md:text-3xl font-bold mb-5"
                style={{ fontFamily: "'Merriweather', serif" }}
              >
                {t('about.missionTitle') || 'Notre Mission'}
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-0">{t('about.missionDesc')}</p>
            </div>
            <div className="p-10 md:p-14">
              <p className="section-label mb-4">{language === 'fr' ? 'Vision' : 'Vision'}</p>
              <h2
                className="text-2xl md:text-3xl font-bold mb-5"
                style={{ fontFamily: "'Merriweather', serif" }}
              >
                {t('about.visionTitle') || 'Notre Vision'}
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-0">{t('about.visionDesc')}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="section-dark py-20 md:py-28">
        <div className="container-wp">
          <div className="mb-12">
            <p className="section-label text-white/40 mb-3">{language === 'fr' ? 'Ce en quoi nous croyons' : 'What we believe in'}</p>
            <h2
              className="display-title text-white m-0"
            >
              {t('about.valuesTitle') || 'Nos Valeurs'}
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-0 border border-white/10">
            {values.map((value, i) => (
              <div key={i} className="p-8 border-b md:border-b-0 md:border-r border-white/10 last:border-0">
                <div
                  className="w-8 h-1 mb-6 rounded-sm"
                  style={{ backgroundColor: 'hsl(43, 96%, 50%)' }}
                />
                <h3
                  className="text-xl font-bold text-white mb-4"
                  style={{ fontFamily: "'Merriweather', serif" }}
                >
                  {value.title}
                </h3>
                <p className="text-white/60 text-sm leading-relaxed mb-0">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Governance */}
      <section className="py-20 md:py-28 bg-white border-b border-border">
        <div className="container-wp max-w-5xl">
          <div className="mb-12">
            <p className="section-label mb-3">{language === 'fr' ? 'Organisation' : 'Organization'}</p>
            <h2
              className="display-title text-foreground m-0 mb-4"
            >
              {t('about.govTitle') || 'Gouvernance'}
            </h2>
            <p className="text-muted-foreground max-w-2xl">{t('about.govDesc')}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              { title: t('about.boardTitle'), desc: t('about.boardDesc') },
              { title: t('about.teamTitle'), desc: t('about.teamDesc') },
            ].map((item, i) => (
              <div key={i} className="p-8 border border-border">
                <div
                  className="w-8 h-1 mb-5 rounded-sm"
                  style={{ backgroundColor: 'hsl(213, 60%, 35%)' }}
                />
                <h3
                  className="text-xl font-bold text-foreground mb-3"
                  style={{ fontFamily: "'Merriweather', serif" }}
                >
                  {item.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed mb-0">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-muted/30 border-b border-border">
        <div className="container-wp flex flex-col md:flex-row items-center justify-between gap-6">
          <p
            className="text-xl font-bold text-foreground m-0"
            style={{ fontFamily: "'Merriweather', serif" }}
          >
            {language === 'fr' ? 'Envie de nous rejoindre ?' : 'Want to join us?'}
          </p>
          <Link
            to={`/${language}/nous-contacter`}
            className="inline-flex items-center gap-2 px-7 py-3.5 text-sm font-bold uppercase tracking-wider rounded-sm transition-all duration-200 hover:opacity-90 flex-shrink-0"
            style={{ backgroundColor: 'hsl(43, 96%, 50%)', color: '#2B3441', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem' }}
          >
            {t('nav.partner') || 'Devenir partenaire'}
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>
    </>
  );
}

export default AProposPage;
