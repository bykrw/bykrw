import React, { useEffect, useState, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { GraduationCap, BookOpen, Users, ChevronLeft, ChevronRight, ArrowRight } from 'lucide-react';
import useEmblaCarousel from 'embla-carousel-react';
import Autoplay from 'embla-carousel-autoplay';
import ChildrenGallery from '@/components/ChildrenGallery.jsx';
import { Link } from 'react-router-dom';
import { useTranslation } from '@/hooks/useTranslation.js';

function AnimatedNumber({ value }) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    const end = parseInt(value.replace(/,/g, ''));
    if (isNaN(end)) return;
    const duration = 2000;
    const increment = end / (duration / 16);
    let start = 0;
    const timer = setInterval(() => {
      start += increment;
      if (start >= end) { setCount(end); clearInterval(timer); }
      else setCount(Math.floor(start));
    }, 16);
    return () => clearInterval(timer);
  }, [value]);
  return <span>{count.toLocaleString()}</span>;
}

const carouselImages = [
  { src: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/d574c207a6a3004fe6167dd515724205.jpg', label: 'Enfant 1' },
  { src: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/2bcb5619f552348e5feca5680fd0998a.jpg', label: 'Enfant 2' },
  { src: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/5afe6db1f1324d2741fc185cd01fc86b.jpg', label: 'Enfant 3' },
  { src: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/6791918005d8b489f7b824aa4748087a.jpg', label: 'Enfant 5' },
  { src: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/5a5ff3c4007a38261aef29bb5e00a114.jpg', label: 'Enfant 6' },
  { src: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/15bcadfa152cecd9328ae6ee58ab4d9f.jpg', label: 'Enfant 7' },
  { src: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/06f09c79adc51606996bd37c60eb185b.jpg', label: 'Enfant 8' },
  { src: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/444ba4b63da61bb961cd2f4bd9a690f6.jpg', label: 'Enfant 9' },
  { src: 'https://images.hostinger.com/6ce70769-a0c3-4db9-989a-b2ae8f67df52.png', label: 'Enfant 10' },
  { src: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/f603f5c54009f036fff4d4c3ecf4648b.png', label: 'Enfant 11' },
  { src: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/a718ebf2cb77cd536dd413c34677dddb.png', label: 'Enfant 12' },
  { src: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/4c7000a75ba587679e0db948f6f15442.png', label: 'Enfant 13' },
  { src: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/0771c29d57adbe96c55c621ca844d7f5.png', label: 'Enfant 14' },
  { src: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/f37035d3c5ae3980674835d1a6a44825.png', label: 'Enfant 15' },
  { src: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/c27331740383b69c5946d87aa53782f1.png', label: 'Enfant 16' },
];

function ChildrenCarousel() {
  const autoplay = React.useRef(Autoplay({ delay: 3500, stopOnInteraction: true }));
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true, align: 'center' }, [autoplay.current]);
  const [selectedIndex, setSelectedIndex] = useState(0);

  const scrollPrev = useCallback(() => emblaApi && emblaApi.scrollPrev(), [emblaApi]);
  const scrollNext = useCallback(() => emblaApi && emblaApi.scrollNext(), [emblaApi]);
  const scrollTo = useCallback((i) => emblaApi && emblaApi.scrollTo(i), [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;
    const onSelect = () => setSelectedIndex(emblaApi.selectedScrollSnap());
    emblaApi.on('select', onSelect);
    onSelect();
    return () => emblaApi.off('select', onSelect);
  }, [emblaApi]);

  return (
    <div className="relative w-full">
      <div ref={emblaRef} className="overflow-hidden rounded-sm shadow-2xl border border-white/10">
        <div className="flex">
          {carouselImages.map((item, i) => (
            <div key={i} className="relative shrink-0 w-full" style={{ flex: '0 0 100%' }}>
              <div className="relative aspect-[3/4] overflow-hidden">
                <img
                  src={item.src}
                  alt={`Child supported by Iradukunda Natwe — ${item.label}`}
                  className="w-full h-full object-cover"
                  style={{ objectPosition: 'center 15%' }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                <div
                  className="absolute top-4 right-4 text-white text-xs font-bold px-3 py-1.5 rounded-sm"
                  style={{ backgroundColor: 'rgba(43,52,65,0.8)', fontFamily: "'Barlow Condensed', sans-serif" }}
                >
                  {i + 1} / {carouselImages.length}
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-5">
                  <span
                    className="text-white/80 text-xs font-bold tracking-widest uppercase"
                    style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
                  >
                    Iradukunda Natwe — {item.label}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <button onClick={scrollPrev} aria-label="Image précédente"
        className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-sm bg-black/40 border border-white/20 text-white flex items-center justify-center hover:bg-black/70 active:scale-95 transition-all z-10">
        <ChevronLeft className="w-5 h-5" />
      </button>
      <button onClick={scrollNext} aria-label="Image suivante"
        className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-sm bg-black/40 border border-white/20 text-white flex items-center justify-center hover:bg-black/70 active:scale-95 transition-all z-10">
        <ChevronRight className="w-5 h-5" />
      </button>

      <div className="flex items-center justify-center gap-2 mt-4">
        {carouselImages.map((_, i) => (
          <button
            key={i}
            onClick={() => scrollTo(i)}
            aria-label={`Aller à l'image ${i + 1}`}
            className="rounded-sm transition-all duration-300"
            style={{
              width: i === selectedIndex ? '1.5rem' : '0.5rem',
              height: '0.4rem',
              backgroundColor: i === selectedIndex ? 'hsl(43,96%,50%)' : 'rgba(255,255,255,0.3)',
            }}
          />
        ))}
      </div>
    </div>
  );
}

export default function ChildrenWeSupportPage() {
  const { language } = useTranslation();

  return (
    <main className="min-h-screen bg-background">
      <Helmet>
        <title>Children We Support | Iradukunda Natwe</title>
        <meta name="description" content="Meet the resilient children whose lives are being transformed through education and community support." />
      </Helmet>

      {/* Page Header */}
      <section className="page-header border-b border-border">
        <div className="container-wp max-w-5xl">
          <nav className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-8">
            <Link to={`/${language}`} className="hover:text-primary transition-colors">{language === 'fr' ? 'Accueil' : 'Home'}</Link>
            <span>/</span>
            <span>{language === 'fr' ? 'Enfants soutenus' : 'Children We Support'}</span>
          </nav>
          <p className="section-label mb-3">{language === 'fr' ? 'Programme Enfance' : 'Children Programme'}</p>
          <h1
            className="m-0 mb-5 leading-tight"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: 'clamp(2.2rem, 5vw, 4.5rem)',
              fontWeight: 800,
              textTransform: 'uppercase',
              letterSpacing: '-0.01em',
            }}
          >
            {language === 'fr' ? "L'Éducation, Chemin Vers L'Espoir" : 'Education Is The Pathway To Hope'}
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mb-0">
            {language === 'fr'
              ? 'Chaque enfant mérite la chance de rêver. Rencontrez les jeunes esprits brillants qui réécrivent leur avenir, une salle de classe à la fois.'
              : 'Every child deserves the chance to dream. Meet the bright minds who are rewriting their futures, one classroom at a time.'}
          </p>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 md:py-28 border-b border-border bg-white">
        <div className="container-wp">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-start">
            <div>
              <p className="section-label mb-3">{language === 'fr' ? 'Leur histoire' : 'Their story'}</p>
              <h2
                className="text-2xl md:text-3xl font-bold mb-6"
                style={{ fontFamily: "'Merriweather', serif" }}
              >
                {language === 'fr' ? 'S\'élever au-dessus de l\'adversité' : 'Rising Above Adversity'}
              </h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p className="mb-0">
                  {language === 'fr'
                    ? 'Les enfants de notre programme viennent de familles confrontées à des défis immenses. Beaucoup sont élevés par des mères courageuses qui luttent quotidiennement pour subvenir aux besoins essentiels.'
                    : 'The children in our program come from families facing immense challenges. Many are raised by resilient single mothers who struggle daily to provide basic necessities.'}
                </p>
                <p className="mb-0">
                  {language === 'fr'
                    ? "Dans ces communautés vulnérables, l'éducation est souvent la première chose sacrifiée lorsque la survie est une priorité. En intervenant pour couvrir les frais scolaires, uniformes et fournitures, nous ne faisons pas que scolariser un enfant — nous restaurons l'espoir d'une famille."
                    : 'In these vulnerable communities, education is often the first thing sacrificed when survival is the priority. By stepping in to cover school fees, uniforms, and materials, we restore a family\'s hope.'}
                </p>
              </div>
              <ul className="mt-8 space-y-3">
                {[
                  language === 'fr' ? 'Soutien aux mères seules et veuves' : 'Supporting single mothers and widows',
                  language === 'fr' ? 'Prise en charge complète de la scolarité' : 'Providing full tuition and school supplies',
                  language === 'fr' ? 'Espaces sécurisants pour la croissance' : 'Creating safe spaces for emotional growth',
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-sm font-medium text-foreground">
                    <div
                      className="w-5 h-5 rounded-sm flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: 'hsl(43,96%,50%)' }}
                    >
                      <div className="w-2 h-0.5 bg-white rounded-full" />
                    </div>
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="relative">
              <ChildrenCarousel />
            </div>
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section className="py-20 md:py-28 bg-muted/30 border-b border-border">
        <div className="container-wp">
          <div className="mb-12">
            <p className="section-label mb-3">{language === 'fr' ? 'Portraits' : 'Portraits'}</p>
            <h2
              className="display-title text-foreground m-0"
            >
              {language === 'fr' ? 'Rencontrer Les Enfants' : 'Meet The Children'}
            </h2>
          </div>
          <ChildrenGallery />
        </div>
      </section>

      {/* Stats */}
      <section className="section-dark py-20 md:py-28">
        <div className="container-wp">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-0 border border-white/10">
            {[
              { icon: Users, value: '17', suffix: '', label: language === 'fr' ? 'Enfants pleinement soutenus' : 'Children Fully Supported' },
              { icon: GraduationCap, value: '100', suffix: '%', label: language === 'fr' ? 'Taux de présence scolaire' : 'School Attendance Rate' },
              { icon: BookOpen, value: '14', suffix: '', label: language === 'fr' ? "Années d'engagement" : 'Years of Commitment' },
            ].map((stat, i) => (
              <div key={i} className="flex flex-col items-center text-center p-10 border-b md:border-b-0 md:border-r border-white/10 last:border-0">
                <div
                  className="w-14 h-14 rounded-sm flex items-center justify-center mb-6"
                  style={{ backgroundColor: 'hsl(43,96%,50%)' }}
                >
                  <stat.icon className="w-7 h-7" style={{ color: '#2B3441' }} />
                </div>
                <div
                  className="font-extrabold text-white leading-none mb-2"
                  style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '3.5rem' }}
                >
                  <AnimatedNumber value={stat.value} />{stat.suffix}
                </div>
                <p
                  className="text-white/50 text-xs font-bold uppercase tracking-widest mb-0"
                  style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
                >
                  {stat.label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 border-b border-border bg-white">
        <div className="container-wp max-w-4xl">
          <div className="border border-border p-10 md:p-14 text-center">
            <p className="section-label mb-4">{language === 'fr' ? 'Agir maintenant' : 'Take action'}</p>
            <h2
              className="display-title text-foreground m-0 mb-5"
            >
              {language === 'fr' ? 'Faites Partie De Leur Histoire' : 'Be Part Of Their Story'}
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-8 mx-auto" style={{ maxWidth: '50ch' }}>
              {language === 'fr'
                ? 'Votre soutien finance directement les frais scolaires, les uniformes et les besoins de base, permettant à ces enfants de se concentrer sur ce qui compte le plus : apprendre et grandir.'
                : 'Your support directly funds school fees, uniforms, and basic needs, ensuring these children can focus on what matters most: learning and growing.'}
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                to={`/${language}/nous-contacter`}
                className="inline-flex items-center gap-2 px-8 py-4 text-sm font-bold uppercase tracking-wider rounded-sm transition-all duration-200 hover:opacity-90 active:scale-[0.98]"
                style={{ backgroundColor: 'hsl(43,96%,50%)', color: '#2B3441', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem' }}
              >
                {language === 'fr' ? 'Parrainer un enfant' : 'Sponsor a Child'}
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to={`/${language}/programmes`}
                className="inline-flex items-center gap-2 px-8 py-4 text-sm font-bold uppercase tracking-wider rounded-sm border-2 border-foreground text-foreground hover:bg-foreground hover:text-white transition-all duration-200"
                style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem' }}
              >
                {language === 'fr' ? 'En savoir plus' : 'Learn More'}
              </Link>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
