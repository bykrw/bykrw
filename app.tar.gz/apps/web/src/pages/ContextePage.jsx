import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { useTranslation } from '../hooks/useTranslation.js';

function ContextePage() {
  const { t, language } = useTranslation();

  const challenges = [
    { title: t('context.challenges.women.title'), description: t('context.challenges.women.desc') },
    { title: t('context.challenges.children.title'), description: t('context.challenges.children.desc') },
    { title: t('context.challenges.env.title'), description: t('context.challenges.env.desc') },
  ];

  return (
    <>
      <Helmet>
        <title>{t('context.title')} — Iradukunda Natwe ASBL</title>
        <meta name="description" content={t('context.desc')} />
      </Helmet>

      {/* Page Header */}
      <section className="page-header">
        <div className="container-wp max-w-5xl">
          <nav className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-8">
            <Link to={`/${language}`} className="hover:text-primary transition-colors">{t('nav.home') || 'Accueil'}</Link>
            <span>/</span>
            <span>{t('context.subtitle') || 'Contexte'}</span>
          </nav>
          <p className="section-label mb-3">{t('context.subtitle') || 'Contexte'}</p>
          <h1
            className="m-0 mb-5 leading-tight"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: 'clamp(2.2rem, 5vw, 4.5rem)',
              fontWeight: 800,
              textTransform: 'uppercase',
              letterSpacing: '-0.01em',
            }}
          >
            {t('context.title')}
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mb-0">{t('context.desc')}</p>
        </div>
      </section>

      {/* Narrative */}
      <section className="py-20 md:py-28 border-b border-border bg-white">
        <div className="container-wp max-w-4xl">
          <h2
            className="text-2xl md:text-3xl font-bold mb-8"
            style={{ fontFamily: "'Merriweather', serif" }}
          >
            {t('context.complexTitle')}
          </h2>
          <div className="space-y-5 text-muted-foreground text-lg leading-relaxed mb-16">
            <p className="mb-0">{t('context.complexDesc1')}</p>
            <p className="mb-0">{t('context.complexDesc2')}</p>
          </div>
        </div>
      </section>

      {/* Challenges */}
      <section className="section-dark py-20 md:py-28">
        <div className="container-wp max-w-5xl">
          <p className="section-label text-white/40 mb-3">{language === 'fr' ? 'Principaux défis' : 'Key challenges'}</p>
          <h2 className="display-title text-white mb-12">
            {language === 'fr' ? 'Défis Identifiés' : 'Identified Challenges'}
          </h2>

          <div className="space-y-0 border border-white/10">
            {challenges.map((c, i) => (
              <div key={i} className="flex gap-8 p-8 border-b border-white/10 last:border-b-0">
                <div
                  className="flex-shrink-0 w-10 h-10 flex items-center justify-center font-extrabold text-lg rounded-sm"
                  style={{
                    backgroundColor: 'hsl(43, 96%, 50%)',
                    color: '#2B3441',
                    fontFamily: "'Barlow Condensed', sans-serif",
                  }}
                >
                  {i + 1}
                </div>
                <div>
                  <h3
                    className="text-xl font-bold text-white mb-3"
                    style={{ fontFamily: "'Merriweather', serif" }}
                  >
                    {c.title}
                  </h3>
                  <p className="text-white/60 text-sm leading-relaxed mb-0" style={{ maxWidth: '60ch' }}>
                    {c.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 border-b border-border bg-muted/30">
        <div className="container-wp flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h2
              className="text-xl font-bold m-0 mb-1"
              style={{ fontFamily: "'Merriweather', serif" }}
            >
              {t('context.ctaTitle')}
            </h2>
            <p className="text-muted-foreground text-sm mb-0">{t('context.ctaDesc')}</p>
          </div>
          <Link
            to={`/${language}/programmes`}
            className="inline-flex items-center gap-2 px-7 py-3.5 text-sm font-bold uppercase tracking-wider rounded-sm hover:opacity-90 flex-shrink-0 transition-all"
            style={{ backgroundColor: 'hsl(43, 96%, 50%)', color: '#2B3441', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem' }}
          >
            {t('context.ctaBtn') || 'Nos programmes'}
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>
    </>
  );
}

export default ContextePage;
