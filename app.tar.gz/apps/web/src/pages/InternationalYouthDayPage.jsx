import React, { useCallback, useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Heart,
  Sparkles,
  Users,
  BookOpen,
  Shield,
} from 'lucide-react';
import useEmblaCarousel from 'embla-carousel-react';
import Autoplay from 'embla-carousel-autoplay';
import { useTranslation } from '@/hooks/useTranslation.js';

/** Portraits for International Youth Day — privacy-first (no names/ages) */
export const YOUTH_PORTRAITS = [
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/d574c207a6a3004fe6167dd515724205.jpg',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/2bcb5619f552348e5feca5680fd0998a.jpg',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/5afe6db1f1324d2741fc185cd01fc86b.jpg',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/6791918005d8b489f7b824aa4748087a.jpg',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/5a5ff3c4007a38261aef29bb5e00a114.jpg',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/15bcadfa152cecd9328ae6ee58ab4d9f.jpg',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/06f09c79adc51606996bd37c60eb185b.jpg',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/444ba4b63da61bb961cd2f4bd9a690f6.jpg',
  'https://images.hostinger.com/6ce70769-a0c3-4db9-989a-b2ae8f67df52.png',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/f603f5c54009f036fff4d4c3ecf4648b.png',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/a718ebf2cb77cd536dd413c34677dddb.png',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/4c7000a75ba587679e0db948f6f15442.png',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/0771c29d57adbe96c55c621ca844d7f5.png',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/f37035d3c5ae3980674835d1a6a44825.png',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/c27331740383b69c5946d87aa53782f1.png',
];

function PortraitCarousel() {
  const autoplay = React.useRef(Autoplay({ delay: 3200, stopOnInteraction: true }));
  const [emblaRef, emblaApi] = useEmblaCarousel(
    { loop: true, align: 'center', skipSnaps: false },
    [autoplay.current]
  );
  const [selectedIndex, setSelectedIndex] = useState(0);

  const scrollPrev = useCallback(() => emblaApi?.scrollPrev(), [emblaApi]);
  const scrollNext = useCallback(() => emblaApi?.scrollNext(), [emblaApi]);
  const scrollTo = useCallback((i) => emblaApi?.scrollTo(i), [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return undefined;
    const onSelect = () => setSelectedIndex(emblaApi.selectedScrollSnap());
    emblaApi.on('select', onSelect);
    onSelect();
    return () => emblaApi.off('select', onSelect);
  }, [emblaApi]);

  return (
    <div className="relative w-full">
      <div ref={emblaRef} className="overflow-hidden rounded-sm">
        <div className="flex">
          {YOUTH_PORTRAITS.map((src, i) => (
            <div key={src} className="relative shrink-0 w-full md:w-1/2 lg:w-1/3 px-1.5" style={{ flex: '0 0 100%' }}>
              <div className="relative aspect-[3/4] overflow-hidden rounded-sm border border-white/10">
                <img
                  src={src}
                  alt=""
                  className="w-full h-full object-cover"
                  style={{ objectPosition: 'center 12%' }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-transparent" />
                <div
                  className="absolute bottom-4 left-4 text-white/90 text-xs font-bold uppercase tracking-widest"
                  style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
                >
                  {String(i + 1).padStart(2, '0')} / {String(YOUTH_PORTRAITS.length).padStart(2, '0')}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <button
        type="button"
        onClick={scrollPrev}
        aria-label="Previous"
        className="absolute left-2 top-1/2 -translate-y-1/2 w-11 h-11 rounded-sm bg-black/45 border border-white/25 text-white flex items-center justify-center hover:bg-black/70 active:scale-95 transition-all z-10"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>
      <button
        type="button"
        onClick={scrollNext}
        aria-label="Next"
        className="absolute right-2 top-1/2 -translate-y-1/2 w-11 h-11 rounded-sm bg-black/45 border border-white/25 text-white flex items-center justify-center hover:bg-black/70 active:scale-95 transition-all z-10"
      >
        <ChevronRight className="w-5 h-5" />
      </button>
      <div className="flex items-center justify-center gap-2 mt-5">
        {YOUTH_PORTRAITS.map((_, i) => (
          <button
            key={i}
            type="button"
            onClick={() => scrollTo(i)}
            aria-label={`Portrait ${i + 1}`}
            className="rounded-sm transition-all duration-300"
            style={{
              width: i === selectedIndex ? '1.75rem' : '0.45rem',
              height: '0.4rem',
              backgroundColor: i === selectedIndex ? 'hsl(43,96%,50%)' : 'rgba(255,255,255,0.28)',
            }}
          />
        ))}
      </div>
    </div>
  );
}

function PortraitGrid() {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 md:gap-3">
      {YOUTH_PORTRAITS.map((src, i) => (
        <motion.div
          key={src}
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-20px' }}
          transition={{ duration: 0.45, delay: Math.min(i * 0.04, 0.35) }}
          className="group relative aspect-[3/4] overflow-hidden rounded-sm"
        >
          <img
            src={src}
            alt=""
            className="w-full h-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-60 group-hover:opacity-90 transition-opacity duration-300" />
          <div
            className="absolute bottom-2 left-2 text-white/80 text-[10px] font-bold tracking-widest uppercase"
            style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
          >
            {String(i + 1).padStart(2, '0')}
          </div>
        </motion.div>
      ))}
    </div>
  );
}

export default function InternationalYouthDayPage() {
  const { language } = useTranslation();
  const isFr = language === 'fr';

  const eventsPath = isFr ? `/${language}/evenements` : `/${language}/events`;
  const contactPath = `/${language}/nous-contacter`;
  const childrenPath = `/${language}/children`;
  const programsPath = `/${language}/programmes`;

  const copy = isFr
    ? {
        title: 'Journée Internationale de la Jeunesse | Iradukunda Natwe',
        meta: 'Célébrons la jeunesse burundaise — éducation, protection et espoir avec Iradukunda Natwe ASBL.',
        crumbHome: 'Accueil',
        crumbEvents: 'Événements',
        crumbPage: 'Journée Internationale de la Jeunesse',
        badge: '12 août · Chaque année',
        heroEyebrow: 'Événement · Iradukunda Natwe ASBL',
        heroTitle: 'Journée Internationale de la Jeunesse',
        heroLead:
          'Honorer le courage, la créativité et le potentiel des jeunes que nous accompagnons au Burundi — et réaffirmer notre engagement pour une éducation sûre et une vie digne.',
        ctaPrimary: 'Soutenir la jeunesse',
        ctaSecondary: 'Voir les enfants soutenus',
        meaningLabel: 'Notre engagement',
        meaningTitle: 'Ce que cette journée signifie pour nous',
        meaningBody:
          'La Journée internationale de la jeunesse n’est pas seulement une date au calendrier. Pour Iradukunda Natwe, c’est un moment pour élever la voix des enfants et des adolescents vulnérables, célébrer leurs progrès et rappeler que l’avenir du Burundi se construit dans les salles de classe, les familles et les communautés.',
        pillars: [
          {
            icon: BookOpen,
            title: 'Éducation d’abord',
            desc: 'Frais de scolarité, fournitures et espaces d’apprentissage sûrs pour que chaque enfant puisse rester à l’école.',
          },
          {
            icon: Shield,
            title: 'Protection & dignité',
            desc: 'Un environnement protecteur, un suivi bienveillant et le respect de la vie privée de chaque jeune.',
          },
          {
            icon: Users,
            title: 'Communautés résilientes',
            desc: 'Quand les mères sont autonomisées et les villages soutenus, les jeunes grandissent avec des racines solides.',
          },
          {
            icon: Sparkles,
            title: 'Potentiel illimité',
            desc: 'Nous croyons que chaque regard déterminé porte déjà les germes d’un leadership futur.',
          },
        ],
        missionLabel: 'Mission jeunesse',
        missionTitle: 'Autonomiser la prochaine génération',
        missionBody:
          'Notre programme de protection de l’enfance et d’éducation accompagne des jeunes issus de contextes de grande vulnérabilité. Nous investissons dans la scolarité, la nutrition et le bien-être psychosocial — pour que l’espoir ne soit plus un luxe, mais un droit vécu au quotidien.',
        missionPoints: [
          'Prise en charge scolaire et kits essentiels',
          'Espaces d’appui après l’école sécurisés',
          'Soutien aux familles et aux mères chefs de ménage',
          'Suivi de la fréquentation et du bien-être',
        ],
        galleryLabel: 'Portraits',
        galleryTitle: 'Visages de l’espoir',
        galleryDesc:
          'Ces portraits célèbrent la résilience des enfants que nous soutenons. Aucun nom ni âge n’est affiché — leur dignité et leur vie privée restent prioritaires.',
        storiesLabel: 'Témoignages',
        storiesTitle: 'Histoires d’impact',
        stories: [
          {
            quote:
              'Quand les frais de scolarité ne sont plus un obstacle, un enfant peut enfin se concentrer sur apprendre, jouer et rêver.',
            role: 'Équipe terrain · Protection de l’enfance',
          },
          {
            quote:
              'Soutenir un jeune, c’est aussi soutenir sa mère et sa communauté. L’impact se multiplie génération après génération.',
            role: 'Programme d’autonomisation des femmes',
          },
          {
            quote:
              'Chaque portrait rappelle pourquoi nous agissons : non pas par charité, mais par solidarité et justice.',
            role: 'Iradukunda Natwe ASBL',
          },
        ],
        stats: [
          { value: '400', label: 'enfants protégés (cible 2028)' },
          { value: '100%', label: 'priorité à la scolarisation' },
          { value: '4', label: 'programmes intégrés' },
        ],
        ctaLabel: 'Agir maintenant',
        ctaTitle: 'Investissez dans la jeunesse du Burundi',
        ctaBody:
          'Votre soutien finance l’éducation, la protection et les opportunités qui permettent aux jeunes de transformer leur avenir — et celui de leur communauté.',
        ctaBtn: 'Devenir partenaire',
        ctaPrograms: 'Nos programmes',
      }
    : {
        title: 'International Youth Day | Iradukunda Natwe',
        meta: 'Celebrating Burundian youth — education, protection, and hope with Iradukunda Natwe ASBL.',
        crumbHome: 'Home',
        crumbEvents: 'Events',
        crumbPage: 'International Youth Day',
        badge: 'August 12 · Every year',
        heroEyebrow: 'Event · Iradukunda Natwe ASBL',
        heroTitle: 'International Youth Day',
        heroLead:
          'Honoring the courage, creativity, and potential of the young people we walk alongside in Burundi — and renewing our promise of safe education and a life of dignity.',
        ctaPrimary: 'Support youth',
        ctaSecondary: 'Meet the children we support',
        meaningLabel: 'Our commitment',
        meaningTitle: 'What this day means to us',
        meaningBody:
          'International Youth Day is more than a date on the calendar. For Iradukunda Natwe, it is a moment to lift up the voices of vulnerable children and adolescents, celebrate their progress, and remember that Burundi’s future is built in classrooms, families, and communities.',
        pillars: [
          {
            icon: BookOpen,
            title: 'Education first',
            desc: 'School fees, supplies, and safe learning spaces so every child can stay in school.',
          },
          {
            icon: Shield,
            title: 'Protection & dignity',
            desc: 'A protective environment, caring follow-up, and full respect for every young person’s privacy.',
          },
          {
            icon: Users,
            title: 'Resilient communities',
            desc: 'When mothers are empowered and villages are supported, young people grow with strong roots.',
          },
          {
            icon: Sparkles,
            title: 'Unlimited potential',
            desc: 'We believe every determined gaze already carries the seeds of future leadership.',
          },
        ],
        missionLabel: 'Youth mission',
        missionTitle: 'Empowering the next generation',
        missionBody:
          'Our child protection and education program walks with young people facing deep vulnerability. We invest in schooling, nutrition, and psychosocial well-being — so hope is not a luxury, but a right lived every day.',
        missionPoints: [
          'School sponsorship and essential kits',
          'Safe after-school support spaces',
          'Support for families and mothers heading households',
          'Attendance and well-being follow-up',
        ],
        galleryLabel: 'Portraits',
        galleryTitle: 'Faces of hope',
        galleryDesc:
          'These portraits celebrate the resilience of the children we support. No names or ages are shown — their dignity and privacy always come first.',
        storiesLabel: 'Voices',
        storiesTitle: 'Impact stories',
        stories: [
          {
            quote:
              'When school fees are no longer a barrier, a child can finally focus on learning, playing, and dreaming.',
            role: 'Field team · Child protection',
          },
          {
            quote:
              'Supporting a young person also supports their mother and community. Impact multiplies across generations.',
            role: 'Women’s empowerment program',
          },
          {
            quote:
              'Every portrait reminds us why we act: not out of charity, but out of solidarity and justice.',
            role: 'Iradukunda Natwe ASBL',
          },
        ],
        stats: [
          { value: '400', label: 'children protected (2028 goal)' },
          { value: '100%', label: 'focus on school access' },
          { value: '4', label: 'integrated programs' },
        ],
        ctaLabel: 'Take action',
        ctaTitle: 'Invest in Burundi’s youth',
        ctaBody:
          'Your support funds education, protection, and opportunity so young people can reshape their future — and their community’s.',
        ctaBtn: 'Become a partner',
        ctaPrograms: 'Our programs',
      };

  return (
    <main className="min-h-screen bg-background">
      <Helmet>
        <title>{copy.title}</title>
        <meta name="description" content={copy.meta} />
      </Helmet>

      {/* HERO */}
      <section className="relative min-h-[88dvh] flex items-end overflow-hidden bg-foreground">
        <div className="absolute inset-0 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 opacity-90">
          {YOUTH_PORTRAITS.slice(0, 10).map((src, i) => (
            <div key={src} className={`relative overflow-hidden ${i >= 8 ? 'hidden lg:block' : i >= 6 ? 'hidden md:block' : ''}`}>
              <img
                src={src}
                alt=""
                className="absolute inset-0 w-full h-full object-cover scale-105"
                style={{ objectPosition: 'center 15%' }}
              />
            </div>
          ))}
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-black/35" />
        <div className="absolute left-0 top-0 bottom-0 w-2 md:w-3" style={{ backgroundColor: 'hsl(43, 96%, 50%)' }} />

        <div className="relative z-10 container-wp pb-14 md:pb-20 pt-28 w-full">
          <nav className="flex flex-wrap items-center gap-2 text-xs font-semibold uppercase tracking-widest text-white/55 mb-8">
            <Link to={`/${language}`} className="hover:text-white transition-colors">{copy.crumbHome}</Link>
            <span>/</span>
            <Link to={eventsPath} className="hover:text-white transition-colors">{copy.crumbEvents}</Link>
            <span>/</span>
            <span className="text-white/80">{copy.crumbPage}</span>
          </nav>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
            className="max-w-3xl"
          >
            <span
              className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest px-3 py-1.5 rounded-sm mb-5"
              style={{ backgroundColor: 'hsl(43, 96%, 50%)', color: '#2B3441', fontFamily: "'Barlow Condensed', sans-serif" }}
            >
              <Heart className="w-3.5 h-3.5" />
              {copy.badge}
            </span>
            <p
              className="text-sm font-bold uppercase tracking-widest text-white/65 mb-3"
              style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
            >
              {copy.heroEyebrow}
            </p>
            <h1
              className="text-white m-0 mb-5"
              style={{
                fontFamily: "'Barlow Condensed', sans-serif",
                fontSize: 'clamp(2.4rem, 6vw, 5rem)',
                fontWeight: 800,
                letterSpacing: '-0.01em',
                textTransform: 'uppercase',
                lineHeight: 1.02,
              }}
            >
              {copy.heroTitle}
            </h1>
            <p className="text-white/85 text-lg md:text-xl leading-relaxed mb-9 max-w-2xl">
              {copy.heroLead}
            </p>
            <div className="flex flex-wrap gap-3">
              <Link
                to={contactPath}
                className="inline-flex items-center gap-2 px-7 py-3.5 text-sm font-bold uppercase tracking-wider rounded-sm transition-all duration-200 hover:opacity-90 active:scale-[0.98]"
                style={{ backgroundColor: 'hsl(43, 96%, 50%)', color: '#2B3441', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem' }}
              >
                {copy.ctaPrimary}
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to={childrenPath}
                className="inline-flex items-center gap-2 px-7 py-3.5 text-sm font-bold uppercase tracking-wider rounded-sm border-2 border-white/65 text-white hover:bg-white hover:text-foreground transition-all duration-200 active:scale-[0.98]"
                style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem' }}
              >
                {copy.ctaSecondary}
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* MEANING */}
      <section className="py-20 md:py-28 bg-white border-b border-border">
        <div className="container-wp">
          <p className="section-label mb-2">{copy.meaningLabel}</p>
          <h2 className="display-title text-foreground mb-6 max-w-3xl">{copy.meaningTitle}</h2>
          <p
            className="text-foreground mb-14 max-w-3xl"
            style={{
              fontFamily: "'Merriweather', serif",
              fontSize: 'clamp(1.05rem, 2vw, 1.25rem)',
              fontWeight: 300,
              lineHeight: 1.75,
            }}
          >
            {copy.meaningBody}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-0 border border-border">
            {copy.pillars.map((p, i) => (
              <div
                key={p.title}
                className="p-7 md:p-8 border-b sm:border-b-0 sm:border-r border-border last:border-0 group hover:bg-muted/40 transition-colors duration-200"
              >
                <div
                  className="w-11 h-11 rounded-sm flex items-center justify-center mb-5 transition-transform duration-200 group-hover:scale-105"
                  style={{ backgroundColor: i % 2 === 0 ? 'hsl(43, 96%, 50%)' : 'hsl(213, 60%, 35%)' }}
                >
                  <p.icon className="w-5 h-5" style={{ color: i % 2 === 0 ? '#2B3441' : 'white' }} />
                </div>
                <h3 className="text-base font-bold text-foreground mb-2" style={{ fontFamily: "'Merriweather', serif" }}>
                  {p.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed m-0">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MISSION + CAROUSEL */}
      <section className="section-dark py-20 md:py-28">
        <div className="container-wp">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center mb-16">
            <div>
              <p className="section-label text-white/40 mb-2">{copy.missionLabel}</p>
              <h2 className="display-title text-white mb-5">{copy.missionTitle}</h2>
              <p className="text-white/70 leading-relaxed mb-8 max-w-xl">{copy.missionBody}</p>
              <ul className="space-y-3">
                {copy.missionPoints.map((item) => (
                  <li key={item} className="flex items-start gap-3 text-sm text-white/85">
                    <span
                      className="mt-1.5 w-2 h-2 rounded-sm flex-shrink-0"
                      style={{ backgroundColor: 'hsl(43, 96%, 50%)' }}
                    />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <PortraitCarousel />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-0 border border-white/10">
            {copy.stats.map((s) => (
              <div key={s.label} className="p-8 md:p-10 text-center border-b md:border-b-0 md:border-r border-white/10 last:border-0">
                <div
                  className="font-extrabold text-white leading-none mb-2"
                  style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 'clamp(2.5rem, 5vw, 3.5rem)' }}
                >
                  {s.value}
                </div>
                <p className="text-white/50 text-xs font-bold uppercase tracking-widest m-0" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
                  {s.label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* GALLERY */}
      <section className="py-20 md:py-28 bg-muted/30 border-b border-border">
        <div className="container-wp">
          <p className="section-label mb-2">{copy.galleryLabel}</p>
          <h2 className="display-title text-foreground mb-4">{copy.galleryTitle}</h2>
          <p className="text-muted-foreground text-lg mb-12 max-w-2xl">{copy.galleryDesc}</p>
          <PortraitGrid />
        </div>
      </section>

      {/* STORIES */}
      <section className="py-20 md:py-28 bg-white border-b border-border">
        <div className="container-wp">
          <p className="section-label mb-2">{copy.storiesLabel}</p>
          <h2 className="display-title text-foreground mb-12">{copy.storiesTitle}</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-0 border border-border">
            {copy.stories.map((story, i) => (
              <blockquote
                key={story.role}
                className="p-8 md:p-10 border-b md:border-b-0 md:border-r border-border last:border-0 m-0 hover:bg-muted/30 transition-colors duration-200"
              >
                <div
                  className="text-4xl font-extrabold leading-none mb-5"
                  style={{ fontFamily: "'Barlow Condensed', sans-serif", color: 'hsl(43, 96%, 50%)' }}
                >
                  “
                </div>
                <p
                  className="text-foreground leading-relaxed mb-6"
                  style={{ fontFamily: "'Merriweather', serif", fontWeight: 300, fontSize: '1.05rem' }}
                >
                  {story.quote}
                </p>
                <footer className="text-xs font-bold uppercase tracking-widest text-muted-foreground" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
                  {story.role}
                </footer>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 md:py-28 relative overflow-hidden" style={{ backgroundColor: 'hsl(43, 96%, 50%)' }}>
        <div className="container-wp max-w-3xl text-center relative z-10">
          <p
            className="text-xs font-bold uppercase tracking-widest mb-4"
            style={{ color: 'rgba(43,52,65,0.55)', fontFamily: "'Barlow Condensed', sans-serif" }}
          >
            {copy.ctaLabel}
          </p>
          <h2
            className="m-0 mb-5 leading-tight"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: 'clamp(2rem, 4vw, 3.4rem)',
              fontWeight: 800,
              textTransform: 'uppercase',
              color: '#2B3441',
            }}
          >
            {copy.ctaTitle}
          </h2>
          <p className="text-lg leading-relaxed mb-10 mx-auto" style={{ color: 'rgba(43,52,65,0.8)', maxWidth: '48ch' }}>
            {copy.ctaBody}
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Link
              to={contactPath}
              className="inline-flex items-center gap-2 px-8 py-4 text-sm font-bold uppercase tracking-wider rounded-sm transition-all duration-200 hover:opacity-90 active:scale-[0.98]"
              style={{ backgroundColor: '#2B3441', color: 'white', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem' }}
            >
              {copy.ctaBtn}
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to={programsPath}
              className="inline-flex items-center gap-2 px-8 py-4 text-sm font-bold uppercase tracking-wider rounded-sm border-2 transition-all duration-200 active:scale-[0.98]"
              style={{ borderColor: '#2B3441', color: '#2B3441', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem' }}
            >
              {copy.ctaPrograms}
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
