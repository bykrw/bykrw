import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { useTranslation } from '../hooks/useTranslation.js';

function PhasesPage() {
  const { t, language } = useTranslation();

  const phases = [
    {
      id: 1,
      title: t('phases.timeline.phase1.title'),
      period: t('phases.timeline.phase1.period'),
      description: t('phases.timeline.phase1.desc'),
      details: [0,1,2,3].map(i => t(`phases.timeline.phase1.details.${i}`)),
    },
    {
      id: 2,
      title: t('phases.timeline.phase2.title'),
      period: t('phases.timeline.phase2.period'),
      description: t('phases.timeline.phase2.desc'),
      details: [0,1,2,3].map(i => t(`phases.timeline.phase2.details.${i}`)),
    },
    {
      id: 3,
      title: t('phases.timeline.phase3.title'),
      period: t('phases.timeline.phase3.period'),
      description: t('phases.timeline.phase3.desc'),
      details: [0,1,2,3].map(i => t(`phases.timeline.phase3.details.${i}`)),
    },
  ];

  return (
    <>
      <Helmet>
        <title>{t('phases.title')} — Iradukunda Natwe ASBL</title>
        <meta name="description" content={t('phases.desc')} />
      </Helmet>

      {/* Page Header */}
      <section className="page-header">
        <div className="container-wp max-w-5xl">
          <nav className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-8">
            <Link to={`/${language}`} className="hover:text-primary transition-colors">{t('nav.home') || 'Accueil'}</Link>
            <span>/</span>
            <span>{t('phases.subtitle') || 'Phases'}</span>
          </nav>
          <p className="section-label mb-3">{t('phases.subtitle') || 'Feuille de Route'}</p>
          <h1
            className="m-0 mb-5 leading-tight"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: 'clamp(2.2rem, 5vw, 4.5rem)',
              fontWeight: 800,
              textTransform: 'uppercase',
              letterSpacing: '-0.01em',
            }}
          >
            {t('phases.title')}
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mb-0">{t('phases.desc')}</p>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-20 md:py-28 bg-white">
        <div className="container-wp max-w-4xl">
          <div className="space-y-0 border border-border">
            {phases.map((phase, i) => (
              <div key={phase.id} className="flex border-b border-border last:border-b-0">
                {/* Number column */}
                <div
                  className="flex-shrink-0 w-16 md:w-24 flex items-start justify-center pt-10"
                  style={{ backgroundColor: i === 0 ? 'hsl(43,96%,50%)' : i === 1 ? 'hsl(213,60%,35%)' : '#2B3441' }}
                >
                  <span
                    className="font-extrabold text-white"
                    style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '2.5rem', lineHeight: 1 }}
                  >
                    {phase.id}
                  </span>
                </div>

                {/* Content */}
                <div className="flex-1 p-8 md:p-10">
                  <span
                    className="text-xs font-bold uppercase tracking-widest block mb-2"
                    style={{ color: 'hsl(213,60%,35%)', fontFamily: "'Barlow Condensed', sans-serif" }}
                  >
                    {phase.period}
                  </span>
                  <h2
                    className="text-xl md:text-2xl font-bold text-foreground mb-4"
                    style={{ fontFamily: "'Merriweather', serif" }}
                  >
                    {phase.title}
                  </h2>
                  <p className="text-muted-foreground leading-relaxed mb-6">{phase.description}</p>

                  <div className="border-l-2 pl-6" style={{ borderColor: 'hsl(43,96%,50%)' }}>
                    <h4
                      className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-3"
                      style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
                    >
                      {t('phases.milestonesTitle') || 'Jalons clés'}
                    </h4>
                    <ul className="space-y-2">
                      {phase.details.map((detail, di) => (
                        <li key={di} className="text-sm text-foreground flex items-start gap-2">
                          <span
                            className="mt-1.5 flex-shrink-0 w-1.5 h-1.5 rounded-full"
                            style={{ backgroundColor: 'hsl(43,96%,50%)' }}
                          />
                          {detail}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default PhasesPage;
