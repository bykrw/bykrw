import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowRight, Users, ShieldCheck, Leaf, Heart } from 'lucide-react';
import { useTranslation } from '../hooks/useTranslation.js';
import HomeChildrenSection from '@/components/HomeChildrenSection.jsx';

const PROGRAM_ICONS = [Users, ShieldCheck, Heart, Leaf];

function HomePage() {
  const { t, language } = useTranslation();

  const programs4 = t('home.programs4.items');
  const projects = t('home.projects.items');

  const values = [
    t('home.missionVision.values.solidarity'),
    t('home.missionVision.values.dignity'),
    t('home.missionVision.values.sustainability'),
    t('home.missionVision.values.equity'),
    t('home.missionVision.values.transparency'),
  ];

  return (
    <>
      <Helmet>
        <title>{t('home.tagline') || 'Iradukunda Natwe ASBL — Autonomiser et Protéger'}</title>
        <meta name="description" content={t('home.desc')} />
      </Helmet>

      {/* ── HERO ──────────────────────────────────────────── */}
      <section className="relative min-h-[92dvh] flex items-end overflow-hidden bg-foreground group">
        <img
          src="https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/84cf7f5972c1c40b47317c2debc8a891.jpg"
          alt="Child supported by Iradukunda Natwe"
          className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.02] group-hover:translate-x-1"
          style={{ objectPosition: '50% 30%' }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-black/10" />
        <div
          className="absolute left-0 top-0 bottom-0 w-2 md:w-3"
          style={{ backgroundColor: 'hsl(43, 96%, 50%)' }}
        />
        <div className="relative z-10 container-wp pb-16 md:pb-24 pt-32">
          <div className="max-w-3xl">
            <span
              className="block text-sm font-bold uppercase tracking-widest text-white/70 mb-5"
              style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
            >
              Iradukunda Natwe ASBL — Burundi
            </span>
            <h1
              className="text-white mb-6"
              style={{
                fontFamily: "'Barlow Condensed', sans-serif",
                fontSize: 'clamp(2.2rem, 5.5vw, 5rem)',
                fontWeight: 800,
                letterSpacing: '-0.01em',
                textTransform: 'uppercase',
                lineHeight: 1.05,
              }}
            >
              {t('home.hero.headline')}
            </h1>
            <p className="text-white/85 text-lg md:text-xl leading-relaxed mb-10 max-w-2xl">
              {t('home.hero.subheadline')}
            </p>
            <div className="flex flex-wrap gap-4">
              <Link
                to={`/${language}/programmes`}
                className="inline-flex items-center gap-2 px-7 py-3.5 text-sm font-bold uppercase tracking-wider rounded-sm transition-all duration-200 hover:opacity-90 active:scale-[0.98]"
                style={{ backgroundColor: 'hsl(43, 96%, 50%)', color: '#2B3441', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem' }}
              >
                {t('home.hero.cta1')}
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to={`/${language}/nous-contacter`}
                className="inline-flex items-center gap-2 px-7 py-3.5 text-sm font-bold uppercase tracking-wider rounded-sm border-2 border-white/70 text-white hover:bg-white hover:text-foreground transition-all duration-200 active:scale-[0.98]"
                style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem' }}
              >
                {t('home.hero.cta2')}
              </Link>
              <Link
                to={`/${language}/nous-contacter`}
                className="inline-flex items-center gap-2 px-7 py-3.5 text-sm font-bold uppercase tracking-wider rounded-sm border-2 border-white/40 text-white/80 hover:border-white/70 hover:text-white transition-all duration-200 active:scale-[0.98]"
                style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem' }}
              >
                {t('home.hero.cta3')}
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── MISSION / VISION / VALUES ─────────────────────── */}
      <section className="py-20 md:py-28 bg-white border-b border-border">
        <div className="container-wp">
          <p className="section-label mb-2">{t('home.missionVision.sectionLabel')}</p>
          <h2
            className="display-title text-foreground mb-14"
          >
            {t('home.missionVision.title')}
          </h2>

          {/* Mission + Vision split */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-0 border border-border mb-14">
            <div className="p-8 md:p-10 border-b md:border-b-0 md:border-r border-border">
              <div
                className="w-8 h-1 mb-6 rounded-sm"
                style={{ backgroundColor: 'hsl(43, 96%, 50%)' }}
              />
              <h3
                className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4"
                style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
              >
                {t('home.missionVision.missionTitle')}
              </h3>
              <p
                className="text-foreground leading-relaxed m-0"
                style={{
                  fontFamily: "'Merriweather', serif",
                  fontSize: 'clamp(1.05rem, 2vw, 1.25rem)',
                  fontWeight: 300,
                  lineHeight: 1.7,
                }}
              >
                {t('home.missionVision.missionDesc')}
              </p>
            </div>
            <div className="p-8 md:p-10">
              <div
                className="w-8 h-1 mb-6 rounded-sm"
                style={{ backgroundColor: 'hsl(213, 60%, 35%)' }}
              />
              <h3
                className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4"
                style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
              >
                {t('home.missionVision.visionTitle')}
              </h3>
              <p
                className="text-foreground leading-relaxed m-0"
                style={{
                  fontFamily: "'Merriweather', serif",
                  fontSize: 'clamp(1.05rem, 2vw, 1.25rem)',
                  fontWeight: 300,
                  lineHeight: 1.7,
                }}
              >
                {t('home.missionVision.visionDesc')}
              </p>
            </div>
          </div>

          {/* Core Values */}
          <div className="mb-6">
            <h3
              className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-8"
              style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
            >
              {t('home.missionVision.valuesTitle')}
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-0 border border-border">
              {values.map((val, i) => (
                <div
                  key={i}
                  className="p-6 border-b sm:border-b-0 sm:border-r border-border last:border-0"
                >
                  <div
                    className="text-xs font-bold uppercase tracking-widest mb-3"
                    style={{
                      color: i % 2 === 0 ? 'hsl(43, 96%, 42%)' : 'hsl(213, 60%, 35%)',
                      fontFamily: "'Barlow Condensed', sans-serif",
                    }}
                  >
                    {String(i + 1).padStart(2, '0')}
                  </div>
                  <h4
                    className="font-bold text-foreground mb-2 text-base"
                    style={{ fontFamily: "'Merriweather', serif" }}
                  >
                    {val.title}
                  </h4>
                  <p className="text-sm text-muted-foreground leading-relaxed m-0">
                    {val.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── FOUR PROGRAMS ─────────────────────────────────── */}
      <section className="section-dark py-20 md:py-28">
        <div className="container-wp">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
            <div>
              <p className="section-label text-white/40 mb-2">
                {t('home.programs4.sectionLabel')}
              </p>
              <h2 className="display-title text-white m-0">
                {t('home.programs4.title')}
              </h2>
            </div>
            <Link
              to={`/${language}/programmes`}
              className="text-sm font-semibold text-white/80 hover:text-white inline-flex items-center gap-2 border-b border-white/30 pb-0.5 flex-shrink-0 transition-colors"
            >
              {language === 'fr' ? 'Tous nos programmes' : 'All our programs'}
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <p className="text-white/60 text-base leading-relaxed mb-12 max-w-2xl">
            {t('home.programs4.desc')}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-0 border border-white/10">
            {Array.isArray(programs4) && programs4.map((prog, i) => {
              const Icon = PROGRAM_ICONS[i];
              return (
                <Link
                  key={i}
                  to={`/${language}/programmes`}
                  className="group p-8 md:p-10 border-b md:last:border-b-0 border-r-0 md:odd:border-r border-white/10 hover:bg-white/5 transition-colors duration-200"
                  style={{ borderBottom: i < 2 ? '1px solid rgba(255,255,255,0.1)' : undefined }}
                >
                  <div className="flex items-start gap-4 mb-5">
                    <span
                      className="text-4xl font-extrabold leading-none flex-shrink-0"
                      style={{ fontFamily: "'Barlow Condensed', sans-serif", color: 'rgba(255,255,255,0.15)' }}
                    >
                      {prog.number}
                    </span>
                    <Icon className="w-6 h-6 mt-1 flex-shrink-0" style={{ color: 'hsl(43, 96%, 50%)' }} />
                  </div>
                  <h3
                    className="text-lg font-bold text-white mb-5 leading-snug"
                    style={{ fontFamily: "'Merriweather', serif" }}
                  >
                    {prog.title}
                  </h3>

                  <div className="space-y-3 mb-6">
                    <div>
                      <span className="text-xs font-bold uppercase tracking-widest text-white/40 block mb-1" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
                        {prog.whatWeDoLabel}
                      </span>
                      <p className="text-sm text-white/70 leading-relaxed m-0">{prog.whatWeDo}</p>
                    </div>
                    <div>
                      <span className="text-xs font-bold uppercase tracking-widest text-white/40 block mb-1" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
                        {prog.outcomesLabel}
                      </span>
                      <p className="text-sm leading-relaxed m-0" style={{ color: 'hsl(43, 96%, 60%)' }}>{prog.outcomes}</p>
                    </div>
                    <div>
                      <span className="text-xs font-bold uppercase tracking-widest text-white/40 block mb-1" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
                        {prog.whyMattersLabel}
                      </span>
                      <p className="text-sm text-white/60 leading-relaxed m-0 italic">{prog.whyMatters}</p>
                    </div>
                  </div>

                  <span className="text-sm font-semibold text-white/70 group-hover:text-white inline-flex items-center gap-1 transition-colors">
                    {t('home.programs4.learnMore')}
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── STATS BAND ────────────────────────────────────── */}
      <section className="bg-muted/40 border-b border-border py-16 md:py-20">
        <div className="container-wp">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-12">
            <div>
              <p className="section-label mb-1">
                {language === 'fr' ? 'Chiffres clés' : 'Foundation facts'}
              </p>
              <h2 className="display-title text-foreground m-0">
                {language === 'fr' ? 'Notre Impact' : 'Our Impact'}
              </h2>
            </div>
            <Link
              to={`/${language}/budget`}
              className="text-sm font-semibold text-primary inline-flex items-center gap-2 border-b border-primary/30 pb-0.5 flex-shrink-0 transition-colors hover:border-primary"
            >
              {language === 'fr' ? 'Voir le budget' : 'View the budget'}
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-0 border border-border">
            {[
              { number: '200', label: language === 'fr' ? 'femmes soutenues' : 'women supported', sub: '(cible 2030)' },
              { number: '400', label: language === 'fr' ? 'enfants protégés' : 'children protected', sub: '(cible 2028)' },
              { number: '30K', label: language === 'fr' ? 'arbres plantés' : 'trees planted', sub: '(cible 2028)' },
              { number: '4', label: language === 'fr' ? 'programmes intégrés' : 'integrated programs', sub: '' },
            ].map((s, i) => (
              <div key={i} className="p-8 border-b md:border-b-0 md:border-r border-border last:border-0 text-center">
                <div className="stat-number text-foreground mb-1">{s.number}</div>
                <div className="text-sm font-medium text-foreground mb-1">{s.label}</div>
                {s.sub && <div className="text-xs text-muted-foreground">{s.sub}</div>}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURED PROJECTS ─────────────────────────────── */}
      <section className="py-20 md:py-28 bg-white border-b border-border">
        <div className="container-wp">
          <p className="section-label mb-2">{t('home.projects.sectionLabel')}</p>
          <h2 className="display-title text-foreground mb-4">
            {t('home.projects.title')}
          </h2>
          <p className="text-lg text-muted-foreground mb-14 max-w-2xl">
            {t('home.projects.desc')}
          </p>

          <div className="space-y-0 border border-border">
            {Array.isArray(projects) && projects.map((proj, i) => (
              <div key={i} className="border-b border-border last:border-b-0">
                {/* Project header */}
                <div className="flex items-center gap-4 px-8 py-5 border-b border-border bg-muted/30">
                  <span
                    className="text-3xl font-extrabold leading-none flex-shrink-0"
                    style={{ fontFamily: "'Barlow Condensed', sans-serif", color: 'hsl(43, 96%, 50%)' }}
                  >
                    {proj.number}
                  </span>
                  <h3
                    className="m-0 font-extrabold uppercase text-foreground"
                    style={{
                      fontFamily: "'Barlow Condensed', sans-serif",
                      fontSize: '1.4rem',
                      letterSpacing: '-0.01em',
                    }}
                  >
                    {proj.title}
                  </h3>
                </div>

                {/* Project body */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
                  {/* Left col: Challenge + Solution */}
                  <div className="p-7 md:p-8 border-b md:border-b-0 md:border-r border-border space-y-5">
                    <div>
                      <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground block mb-2" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
                        {t('home.projects.challengeLabel')}
                      </span>
                      <p className="text-sm text-foreground leading-relaxed m-0">{proj.challenge}</p>
                    </div>
                    <div>
                      <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground block mb-2" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
                        {t('home.projects.solutionLabel')}
                      </span>
                      <p className="text-sm text-foreground leading-relaxed m-0">{proj.solution}</p>
                    </div>
                  </div>

                  {/* Mid col: Building + Helps */}
                  <div className="p-7 md:p-8 border-b lg:border-b-0 lg:border-r border-border space-y-5">
                    <div>
                      <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground block mb-2" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
                        {t('home.projects.buildingLabel')}
                      </span>
                      <p className="text-sm text-foreground leading-relaxed m-0">{proj.building}</p>
                    </div>
                    <div>
                      <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground block mb-2" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
                        {t('home.projects.helpsLabel')}
                      </span>
                      <p className="text-sm text-foreground leading-relaxed m-0">{proj.helps}</p>
                    </div>
                  </div>

                  {/* Right col: Impact + Track */}
                  <div className="p-7 md:p-8 space-y-5">
                    <div>
                      <span className="text-xs font-bold uppercase tracking-widest block mb-2" style={{ fontFamily: "'Barlow Condensed', sans-serif", color: 'hsl(213, 60%, 35%)' }}>
                        {t('home.projects.impactLabel')}
                      </span>
                      <p
                        className="text-sm leading-relaxed m-0 font-semibold"
                        style={{ color: 'hsl(43, 96%, 38%)' }}
                      >
                        {proj.impact}
                      </p>
                    </div>
                    <div>
                      <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground block mb-2" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
                        {t('home.projects.trackLabel')}
                      </span>
                      <p className="text-sm text-muted-foreground leading-relaxed m-0 italic">{proj.track}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CHILDREN SHOWCASE ─────────────────────────────── */}
      <HomeChildrenSection />

      {/* ── THREE-COLUMN CARDS ────────────────────────────── */}
      <section className="bg-white border-b border-border py-20 md:py-28">
        <div className="container-wp">
          <p className="section-label mb-2">
            {language === 'fr' ? "En savoir plus sur l'organisation" : 'More about the organization'}
          </p>
          <h2 className="display-title text-foreground mb-12">
            {language === 'fr' ? 'À Propos De Nous' : 'About Us'}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                img: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/6791918005d8b489f7b824aa4748087a.jpg',
                title: language === 'fr' ? 'Notre rôle' : 'Our role',
                desc: language === 'fr'
                  ? "Depuis notre fondation, Iradukunda Natwe ASBL s'est engagée à lutter contre les grandes inégalités au Burundi."
                  : 'Since our founding, Iradukunda Natwe ASBL has been committed to fighting the greatest inequities in Burundi.',
                link: `/${language}/a-propos`,
                linkLabel: language === 'fr' ? 'En savoir plus' : 'Learn more',
              },
              {
                img: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/5a5ff3c4007a38261aef29bb5e00a114.jpg',
                title: language === 'fr' ? 'Comment nous travaillons' : 'How we work',
                desc: language === 'fr'
                  ? 'Nous sommes axés sur des résultats mesurables — des changements réels dans la vie des communautés.'
                  : 'We are focused on measurable results — real changes in the lives of communities.',
                link: `/${language}/phases`,
                linkLabel: language === 'fr' ? 'Nos phases' : 'Our phases',
              },
              {
                img: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/d4ae524296349bedc01f1a7129674824.jpg',
                title: language === 'fr' ? 'Le contexte' : 'The context',
                desc: language === 'fr'
                  ? 'Comprendre les défis complexes auxquels font face les communautés vulnérables au Burundi.'
                  : 'Understanding the complex challenges faced by vulnerable communities in Burundi.',
                link: `/${language}/contexte`,
                linkLabel: language === 'fr' ? 'Le contexte' : 'Read context',
              },
            ].map((card, i) => (
              <Link key={i} to={card.link} className="group block">
                <div className="aspect-video overflow-hidden rounded-sm mb-5">
                  <img
                    src={card.img}
                    alt={card.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <h3
                  className="text-lg font-bold text-foreground mb-2 group-hover:text-primary transition-colors"
                  style={{ fontFamily: "'Merriweather', serif" }}
                >
                  {card.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-3" style={{ maxWidth: '36ch' }}>
                  {card.desc}
                </p>
                <span className="text-sm font-semibold text-primary inline-flex items-center gap-1 border-b border-primary/30 pb-0.5 group-hover:border-primary transition-colors">
                  {card.linkLabel}
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── OVERSEAS DEVELOPMENT PARTNERS ─────────────────── */}
      <section className="bg-white border-b border-border py-20 md:py-28">
        <div className="container-wp">
          <p className="section-label mb-2">
            {language === 'fr' ? 'Collaboration mondiale' : 'Global collaboration'}
          </p>
          <h2 className="display-title text-foreground mb-4">
            {t('home.partners.title')}
          </h2>
          <p className="text-lg text-muted-foreground mb-12 max-w-2xl">
            {t('home.partners.desc')}
          </p>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {[
              { name: language === 'fr' ? 'Pays-Bas' : 'Netherlands', flag: '🇳🇱' },
              { name: language === 'fr' ? 'Pologne' : 'Poland', flag: '🇵🇱' },
              { name: language === 'fr' ? 'Belgique' : 'Belgium', flag: '🇧🇪' },
              { name: language === 'fr' ? 'Rwanda' : 'Rwanda', flag: '🇷🇼' },
              { name: language === 'fr' ? 'Kenya' : 'Kenya', flag: '🇰🇪' },
              { name: language === 'fr' ? 'Tanzanie' : 'Tanzania', flag: '🇹🇿' },
              { name: language === 'fr' ? 'France' : 'France', flag: '🇫🇷' },
              { name: language === 'fr' ? 'New York' : 'New York', flag: '🗽' },
              { name: language === 'fr' ? 'Washington' : 'Washington', flag: '🏛️' },
            ].map((partner, i) => (
              <div
                key={i}
                className="flex flex-col items-center justify-center p-6 md:p-8 rounded-sm border border-border hover:border-primary/50 hover:bg-muted/30 transition-all duration-200 group cursor-pointer"
              >
                <div className="text-4xl md:text-5xl mb-3 group-hover:scale-110 transition-transform duration-200">
                  {partner.flag}
                </div>
                <p className="text-sm md:text-base font-semibold text-foreground text-center group-hover:text-primary transition-colors">
                  {partner.name}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA BAND ──────────────────────────────────────── */}
      <section
        className="py-20 md:py-28 relative overflow-hidden"
        style={{ backgroundColor: 'hsl(43, 96%, 50%)' }}
      >
        <div className="container-wp max-w-3xl text-center relative z-10">
          <h2
            className="m-0 mb-5 leading-tight"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: 'clamp(2rem, 4vw, 3.5rem)',
              fontWeight: 800,
              textTransform: 'uppercase',
              color: '#2B3441',
            }}
          >
            {t('home.joinTitle')}
          </h2>
          <p className="text-lg leading-relaxed mb-10 mx-auto" style={{ color: 'rgba(43,52,65,0.8)', maxWidth: '48ch' }}>
            {t('home.joinDesc')}
          </p>
          <Link
            to={`/${language}/nous-contacter`}
            className="inline-flex items-center gap-2 px-8 py-4 text-sm font-bold uppercase tracking-wider rounded-sm transition-all duration-200 hover:opacity-90 active:scale-[0.98]"
            style={{ backgroundColor: '#2B3441', color: 'white', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem' }}
          >
            {t('nav.partner')}
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>
    </>
  );
}

export default HomePage;
