import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Loader2, MapPin, Mail, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from '../hooks/useTranslation.js';
import pb from '@/lib/pocketbaseClient';

function ContactPage() {
  const { toast } = useToast();
  const { t, language } = useTranslation();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await pb.collection('contact_submissions').create(formData);
      toast({ title: t('contact.success'), description: t('contact.successDesc') });
      setFormData({ name: '', email: '', subject: '', message: '' });
    } catch {
      toast({
        title: language === 'fr' ? 'Erreur lors de l\'envoi' : 'Submission error',
        description: language === 'fr'
          ? 'Une erreur est survenue. Veuillez réessayer.'
          : 'An error occurred. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>{t('nav.contact')} — Iradukunda Natwe ASBL</title>
        <meta name="description" content={t('contact.desc')} />
      </Helmet>

      {/* Page Header */}
      <section className="page-header">
        <div className="container-wp max-w-5xl">
          <nav className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-8">
            <Link to={`/${language}`} className="hover:text-primary transition-colors">{t('nav.home') || 'Accueil'}</Link>
            <span>/</span>
            <span>{t('contact.subtitle') || 'Contact'}</span>
          </nav>
          <p className="section-label mb-3">{t('contact.subtitle') || 'Nous Contacter'}</p>
          <h1
            className="m-0 mb-5 leading-tight"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: 'clamp(2.2rem, 5vw, 4.5rem)',
              fontWeight: 800,
              textTransform: 'uppercase',
              letterSpacing: '-0.01em',
            }}
          >
            {t('contact.title') || 'Contact'}
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mb-0">{t('contact.desc')}</p>
        </div>
      </section>

      <section className="py-20 md:py-28 bg-white border-b border-border">
        <div className="container-wp">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">

            {/* Contact Info */}
            <div>
              <h2
                className="text-2xl md:text-3xl font-bold mb-10"
                style={{ fontFamily: "'Merriweather', serif" }}
              >
                {t('contact.infoTitle') || 'Coordonnées'}
              </h2>

              <div className="space-y-8">
                <div className="flex gap-4">
                  <div
                    className="flex-shrink-0 w-10 h-10 flex items-center justify-center rounded-sm"
                    style={{ backgroundColor: 'hsl(43,96%,50%)' }}
                  >
                    <MapPin className="w-5 h-5" style={{ color: '#2B3441' }} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-1 text-sm uppercase tracking-wide" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
                      {language === 'fr' ? 'Siège Social' : 'Address'}
                    </h4>
                    <address className="not-italic text-muted-foreground text-sm leading-relaxed">
                      Bujumbura, Commune Mugere<br />
                      Zone Musaga, Quartier Kinanira I<br />
                      Burundi
                    </address>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div
                    className="flex-shrink-0 w-10 h-10 flex items-center justify-center rounded-sm"
                    style={{ backgroundColor: 'hsl(213,60%,35%)' }}
                  >
                    <Mail className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-1 text-sm uppercase tracking-wide" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
                      Email
                    </h4>
                    <a href="mailto:contact@iradukunda.org" className="text-primary hover:underline text-sm">
                      contact@iradukunda.org
                    </a>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div
                    className="flex-shrink-0 w-10 h-10 flex items-center justify-center rounded-sm"
                    style={{ backgroundColor: '#2B3441' }}
                  >
                    <Globe className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-1 text-sm uppercase tracking-wide" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
                      {language === 'fr' ? 'Site Web' : 'Website'}
                    </h4>
                    <a
                      href="https://www.iradukunda.org"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:underline text-sm"
                    >
                      www.iradukunda.org
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Form */}
            <div className="border border-border p-8 md:p-10">
              <h2
                className="text-xl font-bold mb-8"
                style={{ fontFamily: "'Merriweather', serif" }}
              >
                {t('contact.formTitle') || 'Envoyer un message'}
              </h2>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="text-xs font-bold uppercase tracking-widest text-muted-foreground" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
                      {t('contact.name') || 'Nom'}
                    </Label>
                    <Input
                      id="name"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleChange}
                      className="rounded-sm"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-xs font-bold uppercase tracking-widest text-muted-foreground" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
                      {t('contact.email') || 'Email'}
                    </Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      required
                      value={formData.email}
                      onChange={handleChange}
                      className="rounded-sm"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="subject" className="text-xs font-bold uppercase tracking-widest text-muted-foreground" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
                    {t('contact.subject') || 'Sujet'}
                  </Label>
                  <Input
                    id="subject"
                    name="subject"
                    required
                    value={formData.subject}
                    onChange={handleChange}
                    className="rounded-sm"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="message" className="text-xs font-bold uppercase tracking-widest text-muted-foreground" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
                    {t('contact.message') || 'Message'}
                  </Label>
                  <Textarea
                    id="message"
                    name="message"
                    required
                    value={formData.message}
                    onChange={handleChange}
                    className="min-h-[140px] resize-y rounded-sm"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 text-sm font-bold uppercase tracking-wider rounded-sm disabled:opacity-50 transition-opacity flex items-center justify-center gap-2"
                  style={{ backgroundColor: 'hsl(213,60%,35%)', color: 'white', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem' }}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      {t('contact.sending') || 'Envoi...'}
                    </>
                  ) : (
                    t('contact.send') || 'Envoyer le message'
                  )}
                </button>
              </form>
            </div>

          </div>
        </div>
      </section>
    </>
  );
}

export default ContactPage;
