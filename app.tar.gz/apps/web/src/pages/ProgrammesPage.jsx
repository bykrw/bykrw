import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowRight, Users, ShieldCheck, Leaf, Heart } from 'lucide-react';
import { useTranslation } from '../hooks/useTranslation.js';

const ICONS = [Users, ShieldCheck, Heart, Leaf];

function ProgrammesPage() {
  const { t, language } = useTranslation();

  const programs = [
    {
      id: 'autonomisation',
      icon: ICONS[0],
      title: t('programs.axes.emp.title'),
      description: t('programs.axes.emp.desc'),
      target: { metric: '200', label: t('programs.axes.emp.targetLabel') },
      actions: [0, 1, 2, 3].map(i => t(`programs.axes.emp.actions.${i}`)),
    },
    {
      id: 'enfance',
      icon: ICONS[1],
      title: t('programs.axes.child.title'),
      description: t('programs.axes.child.desc'),
      target: { metric: '400', label: t('programs.axes.child.targetLabel') },
      actions: [0, 1, 2, 3].map(i => t(`programs.axes.child.actions.${i}`)),
    },
    {
      id: 'sante',
      icon: ICONS[2],
      title: t('programs.axes.health.title'),
      description: t('programs.axes.health.desc'),
      target: { metric: '∞', label: t('programs.axes.health.targetLabel') },
      actions: [0, 1, 2, 3].map(i => t(`programs.axes.health.actions.${i}`)),
    },
    {
      id: 'environnement',
      icon: ICONS[3],
      title: t('programs.axes.env.title'),
      description: t('programs.axes.env.desc'),
      target: { metric: '30K', label: t('programs.axes.env.targetLabel') },
      actions: [0, 1, 2, 3].map(i => t(`programs.axes.env.actions.${i}`)),
    },
  ];

  const bgColors = [
    'hsl(210,20%,97%)',
    'white',
    'hsl(210,20%,97%)',
    'white',
  ];

  return (
    <>
      <Helmet>
        <title>{t('programs.title')} — Iradukunda Natwe ASBL</title>
        <meta name="description" content={t('programs.desc')} />
      </Helmet>

      {/* Page Header */}
      <section className="page-header">
        <div className="container-wp max-w-5xl">
          <nav className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-8">
            <Link to={`/${language}`} className="hover:text-primary transition-colors">
              {t('nav.home') || 'Accueil'}
            </Link>
            <span>/</span>
            <span>{t('programs.subtitle')}</span>
          </nav>
          <p className="section-label mb-3">{t('programs.subtitle')}</p>
          <h1
            className="m-0 mb-5 leading-tight"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: 'clamp(2.2rem, 5vw, 4.5rem)',
              fontWeight: 800,
              textTransform: 'uppercase',
              letterSpacing: '-0.01em',
            }}
          >
            {t('programs.title')}
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mb-0">{t('programs.desc')}</p>
        </div>
      </section>

      {/* Programs Overview — quick nav */}
      <section className="bg-muted/40 border-b border-border py-8">
        <div className="container-wp max-w-5xl">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-0 border border-border">
            {programs.map((prog, i) => (
              <a
                key={prog.id}
                href={`#${prog.id}`}
                className="group flex items-center gap-3 px-5 py-4 border-b md:border-b-0 md:border-r border-border last:border-0 hover:bg-white transition-colors"
              >
                <prog.icon className="w-4 h-4 flex-shrink-0" style={{ color: 'hsl(43,96%,42%)' }} />
                <span
                  className="text-xs font-bold uppercase tracking-wide text-muted-foreground group-hover:text-primary transition-colors"
                  style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
                >
                  {String(i + 1).padStart(2, '0')} — {prog.title.split(' ').slice(0, 3).join(' ')}…
                </span>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Programs Detail */}
      <section className="py-20 md:py-28 bg-white">
        <div className="container-wp max-w-5xl">
          <div className="space-y-0 border border-border">
            {programs.map((prog, i) => (
              <div
                key={prog.id}
                id={prog.id}
                className="border-b border-border last:border-b-0"
              >
                {/* Section heading */}
                <div
                  className="flex items-center gap-4 px-8 py-6 border-b border-border"
                  style={{ backgroundColor: bgColors[i] }}
                >
                  <span
                    className="text-4xl font-extrabold leading-none"
                    style={{ fontFamily: "'Barlow Condensed', sans-serif", color: 'hsl(43, 96%, 50%)' }}
                  >
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <prog.icon className="w-5 h-5 flex-shrink-0" style={{ color: 'hsl(43,96%,42%)' }} />
                  <h2
                    className="m-0 font-extrabold uppercase"
                    style={{
                      fontFamily: "'Barlow Condensed', sans-serif",
                      fontSize: '1.6rem',
                      letterSpacing: '-0.01em',
                      color: 'hsl(213,60%,35%)',
                    }}
                  >
                    {prog.title}
                  </h2>
                </div>

                <div className="flex flex-col lg:flex-row">
                  {/* Content */}
                  <div className="flex-1 p-8 md:p-10">
                    <p className="text-muted-foreground leading-relaxed mb-6">{prog.description}</p>

                    <h4
                      className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4"
                      style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
                    >
                      {t('programs.actionsTitle')}
                    </h4>
                    <ul className="space-y-2 mb-8">
                      {prog.actions.map((action, ai) => (
                        <li key={ai} className="flex items-start gap-3 text-sm text-foreground">
                          <span
                            className="mt-1.5 flex-shrink-0 w-1.5 h-1.5 rounded-full"
                            style={{ backgroundColor: 'hsl(43,96%,50%)' }}
                          />
                          {action}
                        </li>
                      ))}
                    </ul>

                    <Link
                      to={`/${language}/nous-contacter`}
                      className="inline-flex items-center gap-2 text-sm font-semibold text-primary border-b border-primary/30 pb-0.5 hover:border-primary transition-colors"
                    >
                      {t('programs.ctaBtn')}
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>

                  {/* Metric */}
                  <div
                    className="lg:w-64 p-8 flex flex-col justify-center items-center text-center border-t lg:border-t-0 lg:border-l border-border"
                    style={{ backgroundColor: '#2B3441' }}
                  >
                    <span
                      className="text-xs font-bold uppercase tracking-widest text-white/40 mb-2 block"
                      style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
                    >
                      {prog.target.label}
                    </span>
                    <span
                      className="font-extrabold leading-none"
                      style={{
                        fontFamily: "'Barlow Condensed', sans-serif",
                        fontSize: prog.target.metric === '∞' ? '5rem' : '4rem',
                        color: 'hsl(43, 96%, 50%)',
                      }}
                    >
                      {prog.target.metric}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section
        className="py-16 md:py-20 border-t border-border"
        style={{ backgroundColor: 'hsl(43, 96%, 50%)' }}
      >
        <div className="container-wp max-w-3xl text-center">
          <h2
            className="m-0 mb-5"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: 'clamp(1.8rem, 3.5vw, 3rem)',
              fontWeight: 800,
              textTransform: 'uppercase',
              color: '#2B3441',
            }}
          >
            {language === 'fr' ? 'Soutenez Nos Programmes' : 'Support Our Programs'}
          </h2>
          <p className="text-base leading-relaxed mb-8 mx-auto" style={{ color: 'rgba(43,52,65,0.75)', maxWidth: '44ch' }}>
            {language === 'fr'
              ? 'Chaque contribution renforce notre capacité à autonomiser des femmes, protéger des enfants et préserver notre environnement.'
              : 'Every contribution strengthens our ability to empower women, protect children, and preserve our environment.'}
          </p>
          <Link
            to={`/${language}/nous-contacter`}
            className="inline-flex items-center gap-2 px-8 py-4 text-sm font-bold uppercase tracking-wider rounded-sm transition-all duration-200 hover:opacity-90 active:scale-[0.98]"
            style={{ backgroundColor: '#2B3441', color: 'white', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem' }}
          >
            {t('nav.partner')}
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>
    </>
  );
}

export default ProgrammesPage;
