import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { useTranslation } from '../hooks/useTranslation.js';

function BudgetPage() {
  const { t, language } = useTranslation();

  const budgetData = [
    { name: t('budget.items.emp'), value: 35, color: 'hsl(213,60%,35%)' },
    { name: t('budget.items.child'), value: 40, color: 'hsl(43,96%,50%)' },
    { name: t('budget.items.env'), value: 25, color: 'hsl(160,60%,40%)' },
  ];

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white border border-border p-3 shadow-md rounded-sm">
          <p className="font-semibold text-foreground text-sm m-0 mb-1">{payload[0].name}</p>
          <p className="text-2xl font-extrabold m-0" style={{ color: payload[0].payload.color, fontFamily: "'Barlow Condensed', sans-serif" }}>
            {payload[0].value}%
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <>
      <Helmet>
        <title>{t('budget.title')} — Iradukunda Natwe ASBL</title>
        <meta name="description" content={t('budget.desc')} />
      </Helmet>

      {/* Page Header */}
      <section className="page-header">
        <div className="container-wp max-w-5xl">
          <nav className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-8">
            <Link to={`/${language}`} className="hover:text-primary transition-colors">{t('nav.home') || 'Accueil'}</Link>
            <span>/</span>
            <span>{t('budget.subtitle') || 'Budget'}</span>
          </nav>
          <p className="section-label mb-3">{t('budget.subtitle') || 'Transparence Financière'}</p>
          <h1
            className="m-0 mb-5 leading-tight"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: 'clamp(2.2rem, 5vw, 4.5rem)',
              fontWeight: 800,
              textTransform: 'uppercase',
              letterSpacing: '-0.01em',
            }}
          >
            {t('budget.title')}
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mb-0">{t('budget.desc')}</p>
        </div>
      </section>

      {/* Budget Breakdown */}
      <section className="py-20 md:py-28 bg-white border-b border-border">
        <div className="container-wp">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
            {/* Left: breakdown bars */}
            <div>
              <p className="section-label mb-3">{language === 'fr' ? 'Répartition' : 'Breakdown'}</p>
              <h2
                className="text-2xl md:text-3xl font-bold mb-8"
                style={{ fontFamily: "'Merriweather', serif" }}
              >
                {t('budget.allocationTitle')}
              </h2>
              <p className="text-muted-foreground mb-10">{t('budget.allocationDesc')}</p>

              <div className="space-y-6">
                {budgetData.map((item, i) => (
                  <div key={i}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-semibold text-foreground">{item.name}</span>
                      <span
                        className="font-extrabold"
                        style={{ color: item.color, fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1.5rem' }}
                      >
                        {item.value}%
                      </span>
                    </div>
                    <div className="h-2 bg-muted rounded-sm overflow-hidden">
                      <div
                        className="h-full rounded-sm transition-all duration-700"
                        style={{ width: `${item.value}%`, backgroundColor: item.color }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: pie chart */}
            <div className="h-80 border border-border p-4 bg-muted/20">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={budgetData}
                    cx="50%"
                    cy="50%"
                    innerRadius={80}
                    outerRadius={120}
                    paddingAngle={2}
                    dataKey="value"
                    stroke="none"
                  >
                    {budgetData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                  <Legend
                    verticalAlign="bottom"
                    height={36}
                    iconType="square"
                    wrapperStyle={{ fontSize: '12px', fontFamily: "'DM Sans', sans-serif" }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </section>

      {/* Accountability */}
      <section className="section-dark py-20 md:py-28">
        <div className="container-wp max-w-5xl">
          <div className="mb-12">
            <p className="section-label text-white/40 mb-3">{language === 'fr' ? 'Transparence' : 'Transparency'}</p>
            <h2 className="display-title text-white m-0 mb-4">{t('budget.accountabilityTitle')}</h2>
            <p className="text-white/60 max-w-2xl">{t('budget.accountabilityDesc')}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-0 border border-white/10">
            {[
              { title: t('budget.auditsTitle'), desc: t('budget.auditsDesc') },
              { title: t('budget.reportsTitle'), desc: t('budget.reportsDesc') },
            ].map((item, i) => (
              <div key={i} className="p-8 border-b md:border-b-0 md:border-r border-white/10 last:border-0">
                <div className="w-8 h-1 mb-5 rounded-sm" style={{ backgroundColor: 'hsl(43,96%,50%)' }} />
                <h3 className="text-xl font-bold text-white mb-3" style={{ fontFamily: "'Merriweather', serif" }}>
                  {item.title}
                </h3>
                <p className="text-white/60 text-sm leading-relaxed mb-0">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default BudgetPage;
