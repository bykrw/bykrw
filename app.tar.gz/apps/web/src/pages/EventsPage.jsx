import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowRight, Calendar } from 'lucide-react';
import { useTranslation } from '@/hooks/useTranslation.js';
import { YOUTH_PORTRAITS } from './InternationalYouthDayPage.jsx';

export default function EventsPage() {
  const { language } = useTranslation();
  const isFr = language === 'fr';

  const iydPath = isFr
    ? `/${language}/evenements/journee-internationale-de-la-jeunesse`
    : `/${language}/events/international-youth-day`;

  const copy = isFr
    ? {
        title: 'Événements | Iradukunda Natwe ASBL',
        meta: 'Découvrez les événements d’Iradukunda Natwe ASBL — célébrations, plaidoyer et moments de solidarité pour la jeunesse au Burundi.',
        crumb: 'Événements',
        label: 'Agenda',
        heading: 'Nos Événements',
        lead: 'Des moments pour célébrer, mobiliser et amplifier l’impact de nos programmes auprès des communautés et partenaires.',
        featured: 'À la une',
        cardTitle: 'Journée Internationale de la Jeunesse',
        cardDate: '12 août · Chaque année',
        cardDesc:
          'Une célébration du potentiel des jeunes que nous soutenons — éducation, protection et espoir pour le Burundi de demain.',
        cardCta: 'Découvrir l’événement',
        emptyNote: 'D’autres événements seront annoncés ici. Restez connectés.',
      }
    : {
        title: 'Events | Iradukunda Natwe ASBL',
        meta: 'Explore Iradukunda Natwe ASBL events — celebrations, advocacy, and moments of solidarity for youth in Burundi.',
        crumb: 'Events',
        label: 'Calendar',
        heading: 'Our Events',
        lead: 'Moments to celebrate, mobilize, and amplify the impact of our programs with communities and partners.',
        featured: 'Featured',
        cardTitle: 'International Youth Day',
        cardDate: 'August 12 · Every year',
        cardDesc:
          'A celebration of the young people we support — education, protection, and hope for the Burundi of tomorrow.',
        cardCta: 'Explore the event',
        emptyNote: 'More events will be announced here. Stay tuned.',
      };

  return (
    <main className="min-h-screen bg-background">
      <Helmet>
        <title>{copy.title}</title>
        <meta name="description" content={copy.meta} />
      </Helmet>

      <section className="page-header border-b border-border">
        <div className="container-wp max-w-5xl">
          <nav className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-8">
            <Link to={`/${language}`} className="hover:text-primary transition-colors">
              {isFr ? 'Accueil' : 'Home'}
            </Link>
            <span>/</span>
            <span>{copy.crumb}</span>
          </nav>
          <p className="section-label mb-3">{copy.label}</p>
          <h1
            className="m-0 mb-5 leading-tight"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: 'clamp(2.2rem, 5vw, 4.5rem)',
              fontWeight: 800,
              textTransform: 'uppercase',
              letterSpacing: '-0.01em',
            }}
          >
            {copy.heading}
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mb-0">{copy.lead}</p>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-white border-b border-border">
        <div className="container-wp">
          <p className="section-label mb-8">{copy.featured}</p>

          <Link
            to={iydPath}
            className="group grid grid-cols-1 lg:grid-cols-2 gap-0 border border-border overflow-hidden hover:border-primary/40 transition-colors duration-200"
          >
            <div className="relative min-h-[280px] lg:min-h-[420px] overflow-hidden bg-foreground">
              <div className="absolute inset-0 grid grid-cols-3">
                {YOUTH_PORTRAITS.slice(0, 6).map((src) => (
                  <div key={src} className="relative overflow-hidden">
                    <img
                      src={src}
                      alt=""
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                      style={{ objectPosition: 'center 12%' }}
                    />
                  </div>
                ))}
              </div>
              <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent lg:bg-gradient-to-t lg:from-black/40 lg:to-transparent" />
            </div>

            <div className="p-8 md:p-12 flex flex-col justify-center bg-white">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>
                <Calendar className="w-4 h-4" style={{ color: 'hsl(43, 96%, 42%)' }} />
                {copy.cardDate}
              </div>
              <h2
                className="m-0 mb-4 text-foreground group-hover:text-primary transition-colors"
                style={{
                  fontFamily: "'Barlow Condensed', sans-serif",
                  fontSize: 'clamp(1.75rem, 3vw, 2.5rem)',
                  fontWeight: 800,
                  textTransform: 'uppercase',
                  lineHeight: 1.1,
                }}
              >
                {copy.cardTitle}
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-8 max-w-md">{copy.cardDesc}</p>
              <span
                className="inline-flex items-center gap-2 text-sm font-bold uppercase tracking-wider"
                style={{ color: 'hsl(213, 60%, 35%)', fontFamily: "'Barlow Condensed', sans-serif" }}
              >
                {copy.cardCta}
                <ArrowRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-1" />
              </span>
            </div>
          </Link>

          <p className="text-sm text-muted-foreground mt-10 mb-0">{copy.emptyNote}</p>
        </div>
      </section>
    </main>
  );
}
