import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Heart, ImageOff } from 'lucide-react';

export default function ChildrenShowcaseCard({ child, index }) {
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.6, delay: index * 0.1, ease: [0.21, 0.47, 0.32, 0.98] }}
      className="group relative h-full flex flex-col glass-card rounded-2xl overflow-hidden transition-all duration-500 hover:shadow-2xl hover:-translate-y-2 hover:border-primary/40 bg-card"
    >
      {/* Image Container */}
      <div className="relative aspect-[4/5] overflow-hidden w-full bg-muted flex items-center justify-center">
        {/* Skeleton Loader */}
        {isLoading && !hasError && (
          <div className="absolute inset-0 bg-muted animate-pulse flex items-center justify-center z-10">
            <div className="w-12 h-12 rounded-full bg-white/20" />
          </div>
        )}

        {/* Fallback Error UI */}
        {hasError && (
          <div className="absolute inset-0 bg-muted flex flex-col items-center justify-center text-muted-foreground z-10">
            <ImageOff className="w-10 h-10 mb-2 opacity-50" />
            <span className="text-sm font-medium">Image unavailable</span>
          </div>
        )}

        {/* Actual Image - Removed lazy loading and complex filters that might interfere */}
        <img
          src={child.image}
          alt="Child supported by Iradukunda Natwe"
          onLoad={() => setIsLoading(false)}
          onError={() => {
            setIsLoading(false);
            setHasError(true);
          }}
          className={`w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 ${
            isLoading || hasError ? 'opacity-0' : 'opacity-100'
          }`}
        />
        
        {/* Subtle gradient overlay for text readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/0 to-transparent opacity-60 mix-blend-multiply pointer-events-none" />
        

      </div>

      {/* Content Area */}
      <div className="relative p-6 flex flex-col flex-grow z-10 bg-card/60 backdrop-blur-sm">
        <div className="mb-4">
          <div className="w-10 h-1 bg-accent rounded-full mb-4 transform origin-left transition-all duration-300 group-hover:w-full opacity-60" />
          
          {child.story && (
            <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3">
              {child.story}
            </p>
          )}
        </div>
        
        {/* Hover Reveal Action */}
        <div className="mt-auto pt-4 border-t border-border/50 flex items-center justify-between text-sm">
          <span className="font-medium text-primary opacity-0 -translate-x-2 transition-all duration-300 group-hover:opacity-100 group-hover:translate-x-0">
            Read full story
          </span>
          <button 
            className="w-8 h-8 rounded-full bg-secondary/10 flex items-center justify-center text-secondary hover:bg-secondary hover:text-white transition-colors duration-300 shrink-0"
            aria-label="Support this child"
          >
            <Heart className="w-4 h-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}