import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, ImageOff } from 'lucide-react';
import { useTranslation } from '@/hooks/useTranslation.js';

const childrenImages = [
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/d574c207a6a3004fe6167dd515724205.jpg',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/2bcb5619f552348e5feca5680fd0998a.jpg',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/5afe6db1f1324d2741fc185cd01fc86b.jpg',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/6791918005d8b489f7b824aa4748087a.jpg',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/5a5ff3c4007a38261aef29bb5e00a114.jpg',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/15bcadfa152cecd9328ae6ee58ab4d9f.jpg',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/06f09c79adc51606996bd37c60eb185b.jpg',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/444ba4b63da61bb961cd2f4bd9a690f6.jpg',
  'https://images.hostinger.com/6ce70769-a0c3-4db9-989a-b2ae8f67df52.png',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/f603f5c54009f036fff4d4c3ecf4648b.png',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/a718ebf2cb77cd536dd413c34677dddb.png',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/4c7000a75ba587679e0db948f6f15442.png',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/0771c29d57adbe96c55c621ca844d7f5.png',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/f37035d3c5ae3980674835d1a6a44825.png',
  'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/c27331740383b69c5946d87aa53782f1.png',
];

function ChildCard({ src, index }) {
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-30px' }}
      transition={{ duration: 0.5, delay: index * 0.05 }}
      className="group relative aspect-[3/4] overflow-hidden"
    >
      {!loaded && !error && <div className="absolute inset-0 bg-white/10 animate-pulse" />}
      {error && (
        <div className="absolute inset-0 bg-white/5 flex items-center justify-center">
          <ImageOff className="w-8 h-8 text-white/20" />
        </div>
      )}
      <img
        src={src}
        alt="Child supported by Iradukunda Natwe"
        onLoad={() => setLoaded(true)}
        onError={() => { setLoaded(true); setError(true); }}
        className={`w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-105 ${loaded && !error ? 'opacity-100' : 'opacity-0'}`}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
    </motion.div>
  );
}

export default function HomeChildrenSection() {
  const { language } = useTranslation();

  const heading = language === 'fr' ? 'Les Enfants Que Nous Soutenons' : 'Children We Support';
  const subheading = language === 'fr'
    ? "Chaque visage représente une histoire de résilience. Grâce à votre soutien, nous transformons leur avenir par l'éducation et la protection."
    : 'Each face represents a story of resilience. Through your support, we transform their future through education and protection.';
  const ctaText = language === 'fr' ? 'Découvrir leur histoire' : 'Discover Their Stories';

  return (
    <section style={{ backgroundColor: '#2B3441' }} className="py-20 md:py-28">
      <div className="container-wp">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-12"
        >
          <div>
            <p
              className="text-xs font-bold uppercase tracking-widest mb-3"
              style={{ color: 'hsl(43,96%,50%)', fontFamily: "'Barlow Condensed', sans-serif" }}
            >
              {language === 'fr' ? `${childrenImages.length} enfants soutenus` : `${childrenImages.length} children supported`}
            </p>
            <h2
              className="m-0 leading-tight text-white"
              style={{
                fontFamily: "'Barlow Condensed', sans-serif",
                fontSize: 'clamp(2rem, 4vw, 3.5rem)',
                fontWeight: 800,
                textTransform: 'uppercase',
              }}
            >
              {heading}
            </h2>
          </div>
          <p className="text-white/60 text-sm leading-relaxed max-w-sm md:text-right">
            {subheading}
          </p>
        </motion.div>

        {/* Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2 md:gap-3 mb-10">
          {childrenImages.map((src, i) => (
            <ChildCard key={i} src={src} index={i} />
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4, delay: 0.2 }}
        >
          <Link
            to={`/${language}/children`}
            className="inline-flex items-center gap-2 px-7 py-3.5 text-sm font-bold uppercase tracking-wider rounded-sm transition-all duration-200 hover:opacity-90 active:scale-[0.98]"
            style={{ backgroundColor: 'hsl(43,96%,50%)', color: '#2B3441', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem' }}
          >
            {ctaText}
            <ArrowRight className="w-4 h-4" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
