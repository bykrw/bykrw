import React from 'react';
import ChildrenShowcaseCard from './ChildrenShowcaseCard.jsx';

const childrenData = [
  { 
    id: 1, 
    name: 'Ishimwe Claudia', 
    age: 9,
    story: 'This student loves learning new languages and dreams of becoming a teacher. Their optimism brightens up their entire classroom.',
    image: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/d574c207a6a3004fe6167dd515724205.jpg' 
  },
  { 
    id: 2, 
    name: 'Sharom Manirambona', 
    age: 7,
    story: 'This student is incredibly curious and enjoys mathematics. With proper support, they are excelling beyond expectations.',
    image: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/2bcb5619f552348e5feca5680fd0998a.jpg' 
  },
  { 
    id: 3, 
    name: 'Mugisha Amy Keilla', 
    age: 10,
    story: 'A natural leader among their peers, this student helps organize study groups and has a deep passion for community service.',
    image: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/5afe6db1f1324d2741fc185cd01fc86b.jpg' 
  },
  { 
    id: 4, 
    name: 'Iratwenza Lacia Thiena', 
    age: 8,
    story: 'This student has a creative spirit and expresses their joy through drawing. Education gives them a safe space to grow.',
    image: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/8c9f2e1b3a4d5c6e7f8g9h0i1j2k3l4m.jpg' 
  },
  { 
    id: 5, 
    name: 'Baregensabe Guilain', 
    age: 11,
    story: 'Despite facing significant challenges early in life, this student is determined to succeed and hopes to become an engineer.',
    image: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/6791918005d8b489f7b824aa4748087a.jpg' 
  },
  { 
    id: 6, 
    name: 'Ininahazwe Darcy', 
    age: 6,
    story: 'This student just began their educational journey. Their infectious smile and eagerness to learn inspire everyone around them.',
    image: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/5a5ff3c4007a38261aef29bb5e00a114.jpg' 
  },
  { 
    id: 7, 
    name: 'Niyontungane Jean Marie', 
    age: 12,
    story: 'As one of the older students, this child acts as a mentor to younger children, always stepping in to help others.',
    image: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/9i8h7g6f5e4d3c2b1a0z9y8x7w6v5u4t.jpg' 
  },
  { 
    id: 8, 
    name: 'Niyomwungere Divine', 
    age: 9,
    story: 'This student found their confidence through schooling. They love reading stories and hope to write their own book one day.',
    image: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/15bcadfa152cecd9328ae6ee58ab4d9f.jpg' 
  },
  { 
    id: 9, 
    name: 'Abdunego', 
    age: 8,
    story: 'This student has an incredible work ethic. They practice writing daily and are proud of their rapid progress.',
    image: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/06f09c79adc51606996bd37c60eb185b.jpg' 
  },
  { 
    id: 10, 
    name: 'Kaze Lelys', 
    age: 7,
    story: 'This student is bright and energetic, loving to participate in class discussions and outdoor activities.',
    image: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/444ba4b63da61bb961cd2f4bd9a690f6.jpg' 
  },
  {
    id: 11,
    name: '',
    age: null,
    story: 'Focused and determined, this student approaches every lesson with quiet strength and pride in their progress.',
    image: 'https://images.hostinger.com/6ce70769-a0c3-4db9-989a-b2ae8f67df52.png'
  },
  {
    id: 12,
    name: '',
    age: null,
    story: 'A passionate football fan who channels the same energy into schoolwork and teamwork with classmates.',
    image: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/f603f5c54009f036fff4d4c3ecf4648b.png'
  },
  {
    id: 13,
    name: '',
    age: null,
    story: 'Thoughtful and observant, this student thrives when given space to learn and grow with dignity.',
    image: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/a718ebf2cb77cd536dd413c34677dddb.png'
  },
  {
    id: 14,
    name: '',
    age: null,
    story: 'Bright and expressive, this student brings warmth to every classroom and dreams of a fuller future.',
    image: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/4c7000a75ba587679e0db948f6f15442.png'
  },
  {
    id: 15,
    name: '',
    age: null,
    story: 'Resilient and steady, this student shows courage every day by staying committed to education.',
    image: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/0771c29d57adbe96c55c621ca844d7f5.png'
  },
  {
    id: 16,
    name: '',
    age: null,
    story: 'Curious and full of life, this student loves stories, play, and the chance to learn without fear.',
    image: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/f37035d3c5ae3980674835d1a6a44825.png'
  },
  {
    id: 17,
    name: '',
    age: null,
    story: 'Gentle and attentive, this student finds strength in learning and friendship every school day.',
    image: 'https://horizons-cdn.hostinger.com/0252ed08-e3bd-4d98-abce-8e0cd886370e/c27331740383b69c5946d87aa53782f1.png'
  }
];

export default function ChildrenGallery() {
  return (
    <div className="w-full">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8">
        {childrenData.map((child, index) => (
          <ChildrenShowcaseCard 
            key={child.id} 
            child={child} 
            index={index} 
          />
        ))}
      </div>
    </div>
  );
}