import React from 'react';
import { Route, Routes, BrowserRouter as Router, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/sonner';
import ScrollToTop from './components/ScrollToTop.jsx';
import Header from './components/Header.jsx';
import Footer from './components/Footer.jsx';
import HomePage from './pages/HomePage.jsx';
import AProposPage from './pages/AProposPage.jsx';
import ContextePage from './pages/ContextePage.jsx';
import ProgrammesPage from './pages/ProgrammesPage.jsx';
import ChildrenWeSupportPage from './pages/ChildrenWeSupportPage.jsx';
import PhasesPage from './pages/PhasesPage.jsx';
import BudgetPage from './pages/BudgetPage.jsx';
import ContactPage from './pages/ContactPage.jsx';
import EventsPage from './pages/EventsPage.jsx';
import InternationalYouthDayPage from './pages/InternationalYouthDayPage.jsx';
import { LanguageProvider } from './context/LanguageContext.jsx';
import { AuthProvider } from '@/context/AuthContext.jsx';

function AppRoutes() {
  return (
    <>
      <Header />
      <div className="flex-grow">
        <Routes>
          <Route path="/" element={<Navigate to="/fr" replace />} />
          
          {/* Auth Routes (No Prefix - fallback to default lang) */}
          <Route path="/children" element={<Navigate to="/fr/children" replace />} />

          {/* Main Website Routes */}
          <Route path="/:lang" element={<HomePage />} />
          <Route path="/:lang/a-propos" element={<AProposPage />} />
          <Route path="/:lang/contexte" element={<ContextePage />} />
          <Route path="/:lang/programmes" element={<ProgrammesPage />} />
          <Route path="/:lang/children" element={<ChildrenWeSupportPage />} />
          <Route path="/:lang/phases" element={<PhasesPage />} />
          <Route path="/:lang/budget" element={<BudgetPage />} />
          <Route path="/:lang/nous-contacter" element={<ContactPage />} />
          <Route path="/:lang/events" element={<EventsPage />} />
          <Route path="/:lang/evenements" element={<EventsPage />} />
          <Route path="/:lang/events/international-youth-day" element={<InternationalYouthDayPage />} />
          <Route path="/:lang/evenements/journee-internationale-de-la-jeunesse" element={<InternationalYouthDayPage />} />

          <Route path="*" element={<Navigate to="/fr" replace />} />
        </Routes>
      </div>
      <Footer />
    </>
  );
}

function App() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <Router>
          <ScrollToTop />
          <div className="flex flex-col min-h-screen relative">
            <AppRoutes />
          </div>
          <Toaster />
        </Router>
      </LanguageProvider>
    </AuthProvider>
  );
}

export default App;