/// <reference path="../pb_data/types.d.ts" />

onRecordAfterCreateSuccess((e) => {
  const name = e.record.get("name");
  const email = e.record.get("email");
  const subject = e.record.get("subject");
  const message = e.record.get("message");

  const emailSubject = subject
    ? `[Contact Iradukunda] ${subject}`
    : `[Contact Iradukunda] Nouveau message de ${name}`;

  const htmlBody = `
    <h2>Nouveau message de contact – Iradukunda Natwe ASBL</h2>
    <table style="border-collapse:collapse;width:100%;max-width:600px;">
      <tr>
        <td style="padding:8px;font-weight:bold;border:1px solid #ddd;background:#f5f5f5;">Nom</td>
        <td style="padding:8px;border:1px solid #ddd;">${name}</td>
      </tr>
      <tr>
        <td style="padding:8px;font-weight:bold;border:1px solid #ddd;background:#f5f5f5;">Email</td>
        <td style="padding:8px;border:1px solid #ddd;"><a href="mailto:${email}">${email}</a></td>
      </tr>
      <tr>
        <td style="padding:8px;font-weight:bold;border:1px solid #ddd;background:#f5f5f5;">Sujet</td>
        <td style="padding:8px;border:1px solid #ddd;">${subject || "(non précisé)"}</td>
      </tr>
      <tr>
        <td style="padding:8px;font-weight:bold;border:1px solid #ddd;background:#f5f5f5;vertical-align:top;">Message</td>
        <td style="padding:8px;border:1px solid #ddd;white-space:pre-wrap;">${message}</td>
      </tr>
    </table>
    <p style="margin-top:16px;color:#888;font-size:13px;">
      Reçu via le formulaire de contact de <a href="https://www.iradukunda.org">www.iradukunda.org</a>
    </p>
  `;

  const mailerMessage = new MailerMessage({
    from: { name: "Iradukunda Natwe ASBL" },
    to: [{ address: "contact@iradukunda.org" }],
    replyTo: { address: email, name: name },
    subject: emailSubject,
    html: htmlBody,
  });

  try {
    $app.newMailClient().send(mailerMessage);
  } catch (err) {
    $app.logger().error("contact email send failed", "err", String(err));
  }

  e.next();
}, "contact_submissions");
